import React, { useRef, useState } from 'react';
import { 
  UploadCloud, 
  FileSpreadsheet, 
  RefreshCw, 
  Check, 
  FileCheck2, 
  FileText 
} from 'lucide-react';
import { AuditReport, SalesRecord } from '../types';
import { exportCleanedSalesData } from '../utils/excelExport';

interface FileUploaderProps {
  auditReport: AuditReport;
  cleanedRecords: SalesRecord[];
  onFileParsed: (fileBuffer: ArrayBuffer | string, fileName: string) => void;
  onResetToCanonical: () => void;
  isLoading: boolean;
}

export const FileUploader: React.FC<FileUploaderProps> = ({
  auditReport,
  cleanedRecords,
  onFileParsed,
  onResetToCanonical,
  isLoading,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [dragOver, setDragOver] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState<string | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  const handleDrop = (e: React.DragEvent<HTMLElement>) => {
    e.preventDefault();
    setDragOver(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  const processFile = (file: File) => {
    if (file.name.endsWith('.csv')) {
      const reader = new FileReader();
      reader.onload = (evt) => {
        if (typeof evt.target?.result === 'string') {
          onFileParsed(evt.target.result, file.name);
        }
      };
      reader.readAsText(file);
    } else {
      const reader = new FileReader();
      reader.onload = (evt) => {
        if (evt.target?.result instanceof ArrayBuffer) {
          onFileParsed(evt.target.result, file.name);
        }
      };
      reader.readAsArrayBuffer(file);
    }
  };

  const handleDownloadClean = () => {
    exportCleanedSalesData(cleanedRecords);
    setDownloadSuccess('clean');
    setTimeout(() => setDownloadSuccess(null), 3000);
  };

  return (
    <div className="bg-white border border-[#EAE3D8] rounded-2xl p-5 mb-6 shadow-sm shadow-[#75523F]/5">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        {/* Active Source File Card */}
        <div className="flex items-start sm:items-center space-x-3.5">
          <div className="w-12 h-12 rounded-2xl bg-[#F7EFE8] border border-[#E8DACB] flex items-center justify-center shrink-0 shadow-2xs">
            <FileSpreadsheet className="w-6 h-6 text-[#B86B43]" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-[#EBF4ED] text-[#3F754E] border border-[#CDE3D2]">
                Active POS Source
              </span>
              <span className="text-xs text-[#8A7B73]">Sheet: <strong className="text-[#2C211C]">Sales</strong></span>
            </div>
            <h3 className="text-sm font-bold text-[#2C211C] font-mono mt-0.5">
              {auditReport.fileName}
            </h3>
            <p className="text-xs text-[#8A7B73]">
              1,190 raw spreadsheet rows • Row 4 Header (Rows 1–3 skipped) • Cashier dropped • 4 Subtotals & Grand Total excluded
            </p>
          </div>
        </div>

        {/* Dropzone & Actions */}
        <div className="flex flex-wrap items-center gap-2.5">
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            accept=".xlsx, .xls, .csv"
            className="hidden"
          />

          <button
            onClick={() => fileInputRef.current?.click()}
            onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
            onDragLeave={() => setDragOver(false)}
            onDrop={handleDrop}
            className={`px-3.5 py-2 rounded-xl border text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer shadow-2xs ${
              dragOver
                ? 'bg-[#FDF3E7] border-[#C87D55] text-[#8C5338]'
                : 'bg-[#FAF7F2] hover:bg-[#F4ECE3] border-[#EAE3D8] text-[#5C3828] hover:text-[#2C211C]'
            }`}
          >
            <UploadCloud className="w-4 h-4 text-[#B86B43]" />
            <span>Upload File (.xlsx / .csv)</span>
          </button>

          <a
            href="/assets/aistudio/S3mini_NordBrew_June2026_Sales_RAW.xlsx_-_Sales_6c86dde7.csv"
            download="S3mini_NordBrew_June2026_Sales_RAW.csv"
            className="px-3.5 py-2 rounded-xl bg-white hover:bg-[#FAF7F2] border border-[#EAE3D8] text-xs font-semibold text-[#5C3828] hover:text-[#2C211C] flex items-center gap-2 transition-all cursor-pointer shadow-2xs"
          >
            <FileText className="w-4 h-4 text-[#B86B43]" />
            <span>Download Raw POS File</span>
          </a>

          <button
            onClick={handleDownloadClean}
            title="Export audited clean dataset with cashier dropped and subtotals removed"
            className="px-3.5 py-2 rounded-xl bg-[#EBF4ED] hover:bg-[#DEECE1] border border-[#CDE3D2] text-xs font-semibold text-[#2D5A3A] flex items-center gap-2 transition-all cursor-pointer shadow-2xs"
          >
            {downloadSuccess === 'clean' ? (
              <>
                <Check className="w-4 h-4 text-[#3F754E]" />
                <span className="text-[#3F754E]">Exported Clean!</span>
              </>
            ) : (
              <>
                <FileCheck2 className="w-4 h-4 text-[#3F754E]" />
                <span>Export Clean Data (.xlsx)</span>
              </>
            )}
          </button>

          <button
            onClick={onResetToCanonical}
            title="Reload baseline audited dataset"
            className="p-2 rounded-xl bg-white hover:bg-[#FAF7F2] border border-[#EAE3D8] text-[#8A7B73] hover:text-[#2C211C] transition-all cursor-pointer shadow-2xs"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin text-[#B86B43]' : ''}`} />
          </button>
        </div>
      </div>
    </div>
  );
};
