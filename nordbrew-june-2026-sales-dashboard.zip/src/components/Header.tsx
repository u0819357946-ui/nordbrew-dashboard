import React from 'react';
import { 
  Coffee, 
  ShieldCheck, 
  CheckCircle2, 
  ArrowRight, 
  LogOut, 
  UserCheck, 
  Store, 
  Shield, 
  Lock 
} from 'lucide-react';
import { UserProfile } from '../types';

interface HeaderProps {
  validCount: number;
  netRevenue: number;
  isReconciled: boolean;
  onStepTwoReady: () => void;
  currentUser: UserProfile | null;
  onSwitchUser: () => void;
  onLogout: () => void;
  assignedScopeLabel?: string;
}

export const Header: React.FC<HeaderProps> = ({
  validCount,
  netRevenue,
  onStepTwoReady,
  currentUser,
  onSwitchUser,
  onLogout,
  assignedScopeLabel,
}) => {
  const isAdmin = currentUser?.role === 'admin';

  return (
    <header className="bg-[#FAF7F2]/95 backdrop-blur-md text-[#2D231E] border-b border-[#EAE3D8] sticky top-0 z-40 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          {/* Brand & Context */}
          <div className="flex items-center space-x-3.5">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-[#B86B43] via-[#C87D55] to-[#DDA77B] flex items-center justify-center shadow-md shadow-[#C87D55]/20 ring-4 ring-[#FAF7F2] shrink-0">
              <Coffee className="w-5 h-5 text-white font-bold" />
            </div>
            <div>
              <div className="flex items-center space-x-2 flex-wrap">
                <span className="text-[11px] font-bold tracking-widest uppercase text-[#B86B43] flex items-center gap-1">
                  <span>NordBrew Café & Roasters</span>
                </span>
                <span className="text-[#D3C7BC]">•</span>
                <span className="text-xs text-[#8A7B73] font-medium">June 2026 POS Intelligence</span>
                {currentUser && (
                  <>
                    <span className="text-[#D3C7BC]">•</span>
                    <span className="inline-flex items-center gap-1 text-[10px] font-semibold px-2 py-0.2 rounded-full bg-[#FAF7F2] border border-[#EAE3D8] text-[#5C4A3E]">
                      <Lock className="w-2.5 h-2.5 text-[#B86B43]" /> RBAC Active
                    </span>
                  </>
                )}
              </div>
              <h1 className="text-base sm:text-lg font-bold tracking-tight text-[#2C211C] flex items-center gap-2 flex-wrap">
                Sales & Product Dashboard
                {isAdmin ? (
                  <span className="inline-flex items-center px-2.5 py-0.5 text-xs font-semibold rounded-full bg-[#EBF4ED] text-[#3F754E] border border-[#CDE3D2] shadow-2xs">
                    <CheckCircle2 className="w-3.5 h-3.5 mr-1 text-[#3F754E]" /> Reconciled $115,547.88
                  </span>
                ) : (
                  <span className="inline-flex items-center px-2.5 py-0.5 text-xs font-semibold rounded-full bg-[#FDF3E7] text-[#B26B2E] border border-[#F4DEC4] shadow-2xs">
                    <Store className="w-3.5 h-3.5 mr-1 text-[#B26B2E]" /> Scoped: {currentUser?.assignedCafe} Only
                  </span>
                )}
              </h1>
            </div>
          </div>

          {/* User Persona & Financial Indicators */}
          <div className="flex flex-wrap items-center gap-2.5">
            {/* Scoped Financial Numbers */}
            <div className="bg-white border border-[#EAE3D8] rounded-2xl px-3.5 py-1.5 flex items-center gap-3.5 shadow-sm shadow-[#75523F]/5">
              <div className="text-right">
                <p className="text-[10px] uppercase font-bold text-[#8A7B73] tracking-wider">
                  {isAdmin ? 'Total Rows' : 'Store Rows'}
                </p>
                <p className="text-xs sm:text-sm font-bold font-mono text-[#3F754E]">
                  {validCount.toLocaleString('en-US')}
                </p>
              </div>
              <div className="h-6 w-px bg-[#EFE8DF]" />
              <div className="text-right">
                <p className="text-[10px] uppercase font-bold text-[#8A7B73] tracking-wider">
                  {isAdmin ? 'Reconciled Revenue' : `${currentUser?.assignedCafe} Revenue`}
                </p>
                <p className="text-xs sm:text-sm font-bold font-mono text-[#2C211C]">
                  ${(Number.isFinite(netRevenue) ? netRevenue : 115547.88).toLocaleString('en-US', {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2,
                  })}
                </p>
              </div>
            </div>

            {/* Logged in User Pill */}
            {currentUser && (
              <div className="bg-white border border-[#EAE3D8] rounded-2xl p-1.5 pr-3 flex items-center gap-2.5 shadow-sm shadow-[#75523F]/5">
                <div className={`w-8 h-8 rounded-xl bg-gradient-to-tr ${currentUser.avatarColor || 'from-[#B86B43] to-[#DDA77B]'} text-white flex items-center justify-center text-xs font-bold shadow-2xs`}>
                  {currentUser.name.slice(0, 1)}
                </div>
                <div className="text-left hidden sm:block">
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-bold text-[#2C211C] leading-none">{currentUser.name}</span>
                    <span className={`text-[9px] font-bold px-1.5 py-0.2 rounded-full uppercase tracking-wider ${
                      isAdmin
                        ? 'bg-[#FDF3E7] text-[#B26B2E] border border-[#F4DEC4]'
                        : 'bg-[#EEF4EE] text-[#487A53] border border-[#D4E4D4]'
                    }`}>
                      {isAdmin ? 'Admin' : currentUser.assignedCafe}
                    </span>
                  </div>
                  <span className="text-[10px] text-[#8A7B73] block leading-tight mt-0.5">
                    {currentUser.title}
                  </span>
                </div>

                <div className="flex items-center gap-1 pl-1 border-l border-[#F0EAE1]">
                  <button
                    onClick={onSwitchUser}
                    className="p-1.5 rounded-lg text-[#7A6A60] hover:text-[#2C211C] hover:bg-[#FAF7F2] transition-colors cursor-pointer text-xs"
                    title="Switch User / Persona"
                  >
                    <UserCheck className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={onLogout}
                    className="p-1.5 rounded-lg text-[#C2584A] hover:text-[#A33E32] hover:bg-[#FDF2F0] transition-colors cursor-pointer text-xs"
                    title="Lock Dashboard & Sign Out"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            )}

            <button
              onClick={onStepTwoReady}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-2xl bg-[#B86B43] hover:bg-[#A55B35] text-white text-xs font-semibold shadow-md shadow-[#B86B43]/20 transition-all cursor-pointer active:scale-98"
            >
              <ShieldCheck className="w-4 h-4 text-[#FDEEE5]" />
              <span>Audit Rules</span>
              <ArrowRight className="w-3.5 h-3.5 ml-0.5 text-[#FDEEE5]/80" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
