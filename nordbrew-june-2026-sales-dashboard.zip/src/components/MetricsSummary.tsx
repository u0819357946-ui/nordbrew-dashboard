import React from 'react';
import { DollarSign, ShoppingBag, Receipt, Percent, Store, PiggyBank, Coffee } from 'lucide-react';
import { SalesRecord } from '../types';

interface MetricsSummaryProps {
  records: SalesRecord[];
  netRevenue: number;
}

export const MetricsSummary: React.FC<MetricsSummaryProps> = ({ records, netRevenue }) => {
  const safeRecords = Array.isArray(records) ? records : [];
  const safeNetRevenue = Number.isFinite(netRevenue) && netRevenue >= 0 ? netRevenue : 0;

  const totalUnits = safeRecords.reduce((acc, r) => acc + (Number.isFinite(r.units) ? r.units : 0), 0);
  const totalGross = safeRecords.reduce((acc, r) => acc + (Number.isFinite(r.grossAmount) ? r.grossAmount : 0), 0);
  const totalDiscount = safeRecords.reduce((acc, r) => acc + (Number.isFinite(r.discount) ? r.discount : 0), 0);
  const totalProfit = safeRecords.reduce((acc, r) => acc + (Number.isFinite(r.profit) ? r.profit : 0), 0);

  const profitMargin = safeNetRevenue > 0 ? (totalProfit / safeNetRevenue) * 100 : 0;
  const cafesCount = new Set(safeRecords.map((r) => r.cafe)).size;

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3.5 mb-6">
      {/* 1. Net Revenue */}
      <div className="bg-white border border-[#EAE3D8] rounded-2xl p-4 shadow-sm shadow-[#75523F]/5 flex flex-col justify-between hover:shadow-md transition-shadow">
        <div className="flex items-center justify-between text-[#8A7B73] mb-2">
          <span className="text-[11px] font-bold uppercase tracking-wider">June Net Revenue</span>
          <div className="w-7 h-7 rounded-xl bg-[#F7EFE8] text-[#B86B43] flex items-center justify-center border border-[#E8DACB]">
            <DollarSign className="w-3.5 h-3.5" />
          </div>
        </div>
        <div>
          <span className="text-xl font-bold font-mono text-[#2C211C] tracking-tight">
            ${safeNetRevenue.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </span>
          <span className="block text-[10px] text-[#3F754E] font-semibold mt-0.5">Audited & Reconciled</span>
        </div>
      </div>

      {/* 2. Valid Transactions */}
      <div className="bg-white border border-[#EAE3D8] rounded-2xl p-4 shadow-sm shadow-[#75523F]/5 flex flex-col justify-between hover:shadow-md transition-shadow">
        <div className="flex items-center justify-between text-[#8A7B73] mb-2">
          <span className="text-[11px] font-bold uppercase tracking-wider">Transactions</span>
          <div className="w-7 h-7 rounded-xl bg-[#FDF3E7] text-[#B26B2E] flex items-center justify-center border border-[#F4DEC4]">
            <Receipt className="w-3.5 h-3.5" />
          </div>
        </div>
        <div>
          <span className="text-xl font-bold font-mono text-[#2C211C] tracking-tight">
            {safeRecords.length.toLocaleString('en-US')}
          </span>
          <span className="block text-[10px] text-[#8A7B73] font-medium mt-0.5">
            {safeRecords.length === 1181 ? 'Exact 1,181 rows ✓' : `${safeRecords.length} filtered rows`}
          </span>
        </div>
      </div>

      {/* 3. Total Units */}
      <div className="bg-white border border-[#EAE3D8] rounded-2xl p-4 shadow-sm shadow-[#75523F]/5 flex flex-col justify-between hover:shadow-md transition-shadow">
        <div className="flex items-center justify-between text-[#8A7B73] mb-2">
          <span className="text-[11px] font-bold uppercase tracking-wider">Total Units Sold</span>
          <div className="w-7 h-7 rounded-xl bg-[#F3EBE3] text-[#784732] flex items-center justify-center border border-[#E2D2C4]">
            <ShoppingBag className="w-3.5 h-3.5" />
          </div>
        </div>
        <div>
          <span className="text-xl font-bold font-mono text-[#2C211C] tracking-tight">
            {totalUnits.toLocaleString('en-US')}
          </span>
          <span className="block text-[10px] text-[#8A7B73] font-medium mt-0.5">Items fulfilled</span>
        </div>
      </div>

      {/* 4. Gross Profit */}
      <div className="bg-white border border-[#EAE3D8] rounded-2xl p-4 shadow-sm shadow-[#75523F]/5 flex flex-col justify-between hover:shadow-md transition-shadow">
        <div className="flex items-center justify-between text-[#8A7B73] mb-2">
          <span className="text-[11px] font-bold uppercase tracking-wider">Gross Profit</span>
          <div className="w-7 h-7 rounded-xl bg-[#EBF4ED] text-[#3F754E] flex items-center justify-center border border-[#CDE3D2]">
            <PiggyBank className="w-3.5 h-3.5" />
          </div>
        </div>
        <div>
          <span className="text-xl font-bold font-mono text-[#2C211C] tracking-tight">
            ${totalProfit.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </span>
          <span className="block text-[10px] text-[#3F754E] font-semibold mt-0.5">
            {profitMargin.toFixed(1)}% margin
          </span>
        </div>
      </div>

      {/* 5. Discounts Given */}
      <div className="bg-white border border-[#EAE3D8] rounded-2xl p-4 shadow-sm shadow-[#75523F]/5 flex flex-col justify-between hover:shadow-md transition-shadow">
        <div className="flex items-center justify-between text-[#8A7B73] mb-2">
          <span className="text-[11px] font-bold uppercase tracking-wider">Discounts Given</span>
          <div className="w-7 h-7 rounded-xl bg-[#FDF0EE] text-[#C05746] flex items-center justify-center border border-[#F4D7D2]">
            <Percent className="w-3.5 h-3.5" />
          </div>
        </div>
        <div>
          <span className="text-xl font-bold font-mono text-[#2C211C] tracking-tight">
            ${totalDiscount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </span>
          <span className="block text-[10px] text-[#8A7B73] font-medium mt-0.5">
            ${totalGross.toFixed(2)} gross
          </span>
        </div>
      </div>

      {/* 6. Active Cafés */}
      <div className="bg-white border border-[#EAE3D8] rounded-2xl p-4 shadow-sm shadow-[#75523F]/5 flex flex-col justify-between hover:shadow-md transition-shadow">
        <div className="flex items-center justify-between text-[#8A7B73] mb-2">
          <span className="text-[11px] font-bold uppercase tracking-wider">Active Cafés</span>
          <div className="w-7 h-7 rounded-xl bg-[#FAF0E6] text-[#9E6244] flex items-center justify-center border border-[#ECDCCF]">
            <Store className="w-3.5 h-3.5" />
          </div>
        </div>
        <div>
          <span className="text-xl font-bold font-mono text-[#2C211C] tracking-tight">
            {cafesCount} Locations
          </span>
          <span className="block text-[10px] text-[#8A7B73] font-medium mt-0.5">Tallinn, Riga, Vilnius, HKI</span>
        </div>
      </div>
    </div>
  );
};
