import React from 'react';
import { X, Layers, ShieldCheck } from 'lucide-react';
import { ExcludedRow } from '../types';

interface ExcludedRowsModalProps {
  isOpen: boolean;
  onClose: () => void;
  excludedRows: ExcludedRow[];
}

export const ExcludedRowsModal: React.FC<ExcludedRowsModalProps> = ({
  isOpen,
  onClose,
  excludedRows,
}) => {
  if (!isOpen) return null;

  const subtotals = excludedRows.filter((r) => r.type === 'subtotal');
  const grandTotals = excludedRows.filter((r) => r.type === 'grand_total');

  const subtotalsSum = subtotals.reduce((acc, r) => acc + r.amount, 0);
  const grandTotalSum = grandTotals.reduce((acc, r) => acc + r.amount, 0);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#2D231E]/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white border border-[#EAE3D8] rounded-2xl max-w-2xl w-full shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-6 py-4 bg-[#FAF7F2] border-b border-[#F0EAE1] flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-xl bg-[#FDF3E7] border border-[#F4DEC4] flex items-center justify-center text-[#B26B2E]">
              <Layers className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-[#2D231E]">Excluded Rows Audit Log</h3>
              <p className="text-xs text-[#7A6A60]">
                Identified 4 Subtotal rows and 1 Grand Total row in the Product column
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-[#A8988C] hover:text-[#2D231E] hover:bg-[#F0EAE1] transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-4">
          <div className="p-4 rounded-xl bg-[#FDF3E7] border border-[#F4DEC4] text-xs text-[#8C5338] leading-relaxed">
            <strong className="text-[#2D231E] font-bold block mb-1">
              Why these rows are excluded:
            </strong>
            Per the strict data pipeline rules, summary rows present inside the raw spreadsheet product column
            must be excluded to avoid the <strong className="text-[#B86B43]">3× summation trap ($346,643.64)</strong>.
            Excluding these rows ensures only atomic customer transactions are aggregated.
          </div>

          <div className="space-y-2.5">
            <h4 className="text-xs font-bold uppercase tracking-wider text-[#7A6A60]">
              Filtered Rows Breakdown ({excludedRows.length} Rows)
            </h4>

            {excludedRows.map((row, idx) => (
              <div
                key={idx}
                className="p-3.5 rounded-xl bg-[#FAF7F2] border border-[#EAE3D8] flex items-center justify-between gap-4"
              >
                <div className="flex items-center space-x-3">
                  <div
                    className={`w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold ${
                      row.type === 'grand_total'
                        ? 'bg-[#FBEBEA] text-[#C2584A] border border-[#F5D5D0]'
                        : 'bg-[#FDF3E7] text-[#B26B2E] border border-[#F4DEC4]'
                    }`}
                  >
                    #{row.rowNumber}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-[#2D231E] font-mono">
                        {row.product}
                      </span>
                      <span
                        className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded-full ${
                          row.type === 'grand_total'
                            ? 'bg-[#FBEBEA] text-[#C2584A] border border-[#F5D5D0]'
                            : 'bg-[#FDF3E7] text-[#B26B2E] border border-[#F4DEC4]'
                        }`}
                      >
                        {row.type === 'grand_total' ? 'Grand Total Row' : 'Subtotal Row'}
                      </span>
                    </div>
                    <span className="text-[11px] text-[#7A6A60] font-mono">
                      Matched via Product column regex pattern
                    </span>
                  </div>
                </div>

                <div className="text-right font-mono">
                  <span className="text-sm font-bold text-[#2D231E]">
                    ${row.amount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </span>
                  <span className="block text-[10px] text-[#A8988C] uppercase font-semibold">Excluded</span>
                </div>
              </div>
            ))}
          </div>

          {/* Reconciled Summary */}
          <div className="p-4 rounded-xl bg-[#FAF7F2] border border-[#EAE3D8] grid grid-cols-2 gap-4 text-xs font-mono">
            <div>
              <span className="text-[#7A6A60] block text-[11px] font-sans">4 Subtotals Combined:</span>
              <span className="text-[#B86B43] font-bold text-sm">
                ${subtotalsSum.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
            </div>
            <div>
              <span className="text-[#7A6A60] block text-[11px] font-sans">1 Grand Total Value:</span>
              <span className="text-[#B86B43] font-bold text-sm">
                ${grandTotalSum.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 bg-[#FAF7F2] border-t border-[#F0EAE1] flex items-center justify-between">
          <div className="flex items-center space-x-2 text-xs text-[#487A53] font-semibold">
            <ShieldCheck className="w-4 h-4 text-[#487A53]" />
            <span>Audit Passed: Trap Defused</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-[#B86B43] hover:bg-[#A35933] text-xs font-semibold text-white transition-colors cursor-pointer shadow-xs"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
