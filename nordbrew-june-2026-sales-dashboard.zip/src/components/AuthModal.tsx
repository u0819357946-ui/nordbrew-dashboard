import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, 
  Lock, 
  KeyRound, 
  Mail, 
  Smartphone, 
  ArrowRight, 
  CheckCircle2, 
  Coffee, 
  RefreshCw, 
  Eye, 
  EyeOff,
  UserCheck,
  Building2,
  Sparkles,
  AlertCircle
} from 'lucide-react';
import { UserProfile } from '../types';
import { DEMO_USERS } from '../utils/authConfig';

interface AuthModalProps {
  isOpen: boolean;
  onLoginSuccess: (user: UserProfile) => void;
  currentUser?: UserProfile | null;
  onClose?: () => void;
  isSwitchingUser?: boolean;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onLoginSuccess,
  currentUser,
  onClose,
  isSwitchingUser = false,
}) => {
  const [step, setStep] = useState<'credentials' | 'mfa'>('credentials');
  const [selectedUser, setSelectedUser] = useState<UserProfile>(DEMO_USERS[0]);
  const [emailInput, setEmailInput] = useState(DEMO_USERS[0].email);
  const [pinInput, setPinInput] = useState('2026');
  const [showPin, setShowPin] = useState(false);
  const [mfaCode, setMfaCode] = useState('');
  const [simulatedMfaTarget, setSimulatedMfaTarget] = useState('849 203');
  const [mfaError, setMfaError] = useState<string | null>(null);
  const [credError, setCredError] = useState<string | null>(null);
  const [timer, setTimer] = useState(60);
  const [isVerifying, setIsVerifying] = useState(false);

  // Sync selected user when preset is clicked
  const handleSelectPreset = (user: UserProfile & { defaultPin: string }) => {
    setSelectedUser(user);
    setEmailInput(user.email);
    setPinInput(user.defaultPin);
    setCredError(null);
  };

  // Generate new simulated MFA 6-digit code
  const generateNewMfaCode = () => {
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    const formatted = `${code.slice(0, 3)} ${code.slice(3)}`;
    setSimulatedMfaTarget(formatted);
    setTimer(60);
    setMfaError(null);
  };

  // MFA Countdown Timer
  useEffect(() => {
    if (step === 'mfa' && timer > 0) {
      const interval = setInterval(() => setTimer((t) => t - 1), 1000);
      return () => clearInterval(interval);
    }
  }, [step, timer]);

  // Handle Step 1 Submit
  const handleCredentialsSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setCredError(null);

    if (!emailInput.trim()) {
      setCredError('Please enter a valid work email.');
      return;
    }

    if (!pinInput.trim() || pinInput.length < 3) {
      setCredError('Please enter your secure 4-digit PIN or password.');
      return;
    }

    // Determine user profile
    const matched = DEMO_USERS.find(
      (u) => u.email.toLowerCase() === emailInput.trim().toLowerCase()
    );

    let activeUser: UserProfile;
    if (matched) {
      activeUser = matched;
    } else {
      // Dynamic fallback for custom email
      const isManager = emailInput.toLowerCase().includes('manager') || emailInput.toLowerCase().includes('store');
      activeUser = {
        id: `usr_${Date.now()}`,
        name: emailInput.split('@')[0].replace(/[._]/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase()),
        email: emailInput.trim(),
        role: isManager ? 'manager' : 'admin',
        title: isManager ? 'Store Manager (Custom)' : 'Finance Director',
        assignedCafe: isManager ? 'Riga' : 'all',
        phoneHint: '+371 20 ••• •99',
        avatarColor: 'from-[#B86B43] to-[#DDA77B]',
      };
    }

    setSelectedUser(activeUser);
    generateNewMfaCode();
    setStep('mfa');
  };

  // Handle MFA auto-fill convenience
  const handleAutoFillCode = () => {
    const raw = simulatedMfaTarget.replace(/\s/g, '');
    setMfaCode(raw);
    setMfaError(null);
  };

  // Handle Step 2 MFA Submit
  const handleMfaSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setMfaError(null);

    const cleanInput = mfaCode.replace(/\s/g, '');
    const cleanTarget = simulatedMfaTarget.replace(/\s/g, '');

    if (cleanInput !== cleanTarget && cleanInput !== '123456' && cleanInput !== '202600') {
      setMfaError('Invalid verification code. Please check the simulated code badge or click Auto-fill.');
      return;
    }

    setIsVerifying(true);
    setTimeout(() => {
      setIsVerifying(false);
      onLoginSuccess(selectedUser);
    }, 600);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#2C211C]/75 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-white border border-[#EAE3D8] rounded-3xl max-w-lg w-full shadow-2xl shadow-[#75523F]/20 overflow-hidden flex flex-col relative transition-all">
        
        {/* Top Decorative Café Ribbon */}
        <div className="h-2.5 w-full bg-gradient-to-r from-[#B86B43] via-[#C87D55] to-[#DDA77B]" />

        {/* Modal Header */}
        <div className="p-6 pb-4 bg-[#FAF7F2] border-b border-[#F0EAE1] flex items-center justify-between">
          <div className="flex items-center space-x-3.5">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-[#B86B43] to-[#DDA77B] flex items-center justify-center text-white shadow-md shadow-[#B86B43]/20 ring-4 ring-[#FAF7F2]">
              <Coffee className="w-6 h-6 font-bold" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-[10px] font-bold uppercase tracking-wider text-[#B86B43] font-mono">
                  NordBrew Security Gateway
                </span>
                <span className="text-[10px] px-2 py-0.2 rounded-full bg-[#EBF4ED] text-[#3F754E] font-medium border border-[#CDE3D2]">
                  MFA Protected
                </span>
              </div>
              <h2 className="text-lg font-bold text-[#2C211C] tracking-tight">
                {step === 'credentials' ? 'Enterprise Sign In' : 'Two-Factor Authentication'}
              </h2>
            </div>
          </div>

          {/* Close button only available if user is already authenticated and just switching persona */}
          {isSwitchingUser && currentUser && onClose && (
            <button
              onClick={onClose}
              className="text-xs text-[#8A7B73] hover:text-[#2C211C] p-2 rounded-xl hover:bg-[#F2ECE3] transition-colors cursor-pointer"
            >
              Cancel
            </button>
          )}
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto max-h-[80vh]">
          {step === 'credentials' ? (
            <form onSubmit={handleCredentialsSubmit} className="space-y-4">
              <div className="text-xs text-[#7A6A60] leading-relaxed">
                Welcome to NordBrew's June 2026 Financial & POS Pipeline. Access is strictly controlled based on organizational role:
              </div>

              {/* Persona Quick Selector (Radio Cards) */}
              <div className="space-y-2">
                <label className="text-[11px] font-bold uppercase tracking-wider text-[#8A7B73] block">
                  Select Role / Account Persona:
                </label>
                <div className="grid grid-cols-1 gap-2">
                  {DEMO_USERS.map((u) => {
                    const isSelected = selectedUser.id === u.id;
                    const isAdmin = u.role === 'admin';

                    return (
                      <div
                        key={u.id}
                        onClick={() => handleSelectPreset(u)}
                        className={`p-3 rounded-2xl border text-left cursor-pointer transition-all flex items-center justify-between ${
                          isSelected
                            ? 'bg-[#FAF7F2] border-[#B86B43] ring-2 ring-[#B86B43]/20 shadow-xs'
                            : 'bg-white border-[#EAE3D8] hover:bg-[#FAF7F2]/60 hover:border-[#D9CEC1]'
                        }`}
                      >
                        <div className="flex items-center space-x-3">
                          <div className={`w-8 h-8 rounded-xl bg-gradient-to-tr ${u.avatarColor} text-white flex items-center justify-center text-xs font-bold shadow-2xs`}>
                            {u.name.slice(0, 1)}
                          </div>
                          <div>
                            <div className="flex items-center gap-1.5">
                              <span className="text-xs font-bold text-[#2C211C]">{u.name}</span>
                              <span className={`text-[10px] font-semibold px-2 py-0.2 rounded-full ${
                                isAdmin
                                  ? 'bg-[#FDF3E7] text-[#B26B2E] border border-[#F4DEC4]'
                                  : 'bg-[#EEF4EE] text-[#487A53] border border-[#D4E4D4]'
                              }`}>
                                {isAdmin ? 'Admin / Finance' : 'Store Manager'}
                              </span>
                            </div>
                            <p className="text-[11px] text-[#7A6A60]">{u.title}</p>
                          </div>
                        </div>

                        <div className="text-right">
                          <span className={`text-[10px] font-mono font-bold block ${
                            isAdmin ? 'text-[#B86B43]' : 'text-[#487A53]'
                          }`}>
                            {isAdmin ? 'All 4 Cafés ($115k)' : `${u.assignedCafe} Only`}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Email & Password Input Fields */}
              <div className="pt-2 border-t border-[#F0EAE1] space-y-3">
                <div>
                  <label className="text-[11px] font-bold uppercase tracking-wider text-[#8A7B73] block mb-1">
                    Work Email
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-[#A8988C] absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="email"
                      value={emailInput}
                      onChange={(e) => setEmailInput(e.target.value)}
                      placeholder="name@nordbrew.com"
                      required
                      className="w-full bg-[#FAF7F2] border border-[#EAE3D8] rounded-xl pl-9 pr-3 py-2 text-xs text-[#2C211C] font-mono focus:outline-none focus:border-[#B86B43] focus:bg-white transition-colors"
                    />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between items-center mb-1">
                    <label className="text-[11px] font-bold uppercase tracking-wider text-[#8A7B73]">
                      Security PIN / Password
                    </label>
                    <span className="text-[10px] text-[#A8988C] font-mono">Demo PIN: 2026</span>
                  </div>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-[#A8988C] absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type={showPin ? 'text' : 'password'}
                      value={pinInput}
                      onChange={(e) => setPinInput(e.target.value)}
                      placeholder="Enter PIN (e.g. 2026)"
                      required
                      className="w-full bg-[#FAF7F2] border border-[#EAE3D8] rounded-xl pl-9 pr-10 py-2 text-xs text-[#2C211C] font-mono focus:outline-none focus:border-[#B86B43] focus:bg-white transition-colors"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPin(!showPin)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-[#A8988C] hover:text-[#2C211C] cursor-pointer"
                    >
                      {showPin ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
              </div>

              {credError && (
                <div className="p-3 rounded-xl bg-[#FBEBEA] border border-[#F5D5D0] text-[#C2584A] text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{credError}</span>
                </div>
              )}

              {/* Submit Button */}
              <button
                type="submit"
                className="w-full py-3 px-4 rounded-2xl bg-[#B86B43] hover:bg-[#A55B35] text-white font-bold text-xs shadow-md shadow-[#B86B43]/20 flex items-center justify-center gap-2 transition-all cursor-pointer mt-2"
              >
                <span>Continue to MFA Step</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          ) : (
            /* STEP 2: MFA VERIFICATION */
            <form onSubmit={handleMfaSubmit} className="space-y-4">
              <div className="p-4 rounded-2xl bg-[#FAF7F2] border border-[#EAE3D8] space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Smartphone className="w-4 h-4 text-[#B86B43]" />
                    <span className="text-xs font-bold text-[#2C211C]">Two-Factor Challenge</span>
                  </div>
                  <span className="text-[10px] font-mono text-[#8A7B73]">SMS & Authenticator</span>
                </div>
                <p className="text-xs text-[#7A6A60] leading-relaxed">
                  A 6-digit one-time security code has been dispatched for <strong className="text-[#2C211C]">{selectedUser.name}</strong> ({selectedUser.phoneHint || selectedUser.email}).
                </p>
              </div>

              {/* Simulated Code Visual Callout */}
              <div className="p-3.5 rounded-2xl bg-[#FDF3E7] border border-[#F4DEC4] flex items-center justify-between gap-3">
                <div>
                  <span className="text-[10px] uppercase font-bold text-[#B26B2E] block tracking-wider">
                    Simulated Security Code
                  </span>
                  <span className="text-lg font-bold font-mono text-[#8C5338] tracking-widest">
                    {simulatedMfaTarget}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={handleAutoFillCode}
                  className="px-3 py-1.5 rounded-xl bg-[#B86B43] hover:bg-[#A55B35] text-white text-[11px] font-semibold cursor-pointer shadow-xs transition-colors flex items-center gap-1"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Auto-fill Code</span>
                </button>
              </div>

              {/* MFA Code Input */}
              <div>
                <label className="text-[11px] font-bold uppercase tracking-wider text-[#8A7B73] block mb-1">
                  Enter 6-Digit Verification Code:
                </label>
                <div className="relative">
                  <KeyRound className="w-4 h-4 text-[#A8988C] absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    maxLength={7}
                    value={mfaCode}
                    onChange={(e) => {
                      const val = e.target.value.replace(/[^\d]/g, '');
                      setMfaCode(val);
                      setMfaError(null);
                    }}
                    placeholder="e.g. 849203"
                    autoFocus
                    required
                    className="w-full bg-[#FAF7F2] border border-[#EAE3D8] rounded-xl pl-9 pr-3 py-2.5 text-center text-base tracking-widest font-mono font-bold text-[#2C211C] focus:outline-none focus:border-[#B86B43] focus:bg-white transition-colors"
                  />
                </div>
              </div>

              {/* Timer & Resend */}
              <div className="flex items-center justify-between text-xs text-[#7A6A60]">
                <span>
                  Code expires in: <strong className="text-[#2C211C] font-mono">{timer}s</strong>
                </span>
                <button
                  type="button"
                  onClick={generateNewMfaCode}
                  disabled={timer > 45}
                  className="text-[#B86B43] hover:text-[#A55B35] disabled:text-[#A8988C] disabled:cursor-not-allowed font-medium flex items-center gap-1 cursor-pointer"
                >
                  <RefreshCw className="w-3 h-3" />
                  <span>Resend Code</span>
                </button>
              </div>

              {mfaError && (
                <div className="p-3 rounded-xl bg-[#FBEBEA] border border-[#F5D5D0] text-[#C2584A] text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{mfaError}</span>
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex items-center gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setStep('credentials')}
                  className="w-1/3 py-2.5 px-3 rounded-2xl bg-[#F7F2EB] hover:bg-[#EFE7DC] text-[#5C4A3E] font-semibold text-xs border border-[#EAE3D8] transition-colors cursor-pointer"
                >
                  Back
                </button>
                <button
                  type="submit"
                  disabled={isVerifying || mfaCode.length < 5}
                  className="flex-1 py-2.5 px-4 rounded-2xl bg-[#B86B43] hover:bg-[#A55B35] disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold text-xs shadow-md shadow-[#B86B43]/20 flex items-center justify-center gap-2 transition-all cursor-pointer"
                >
                  {isVerifying ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>Verifying Token...</span>
                    </>
                  ) : (
                    <>
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Verify & Access Dashboard</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          )}
        </div>

        {/* Modal Security Footer */}
        <div className="p-4 bg-[#FAF7F2] border-t border-[#F0EAE1] flex items-center justify-between text-[11px] text-[#8A7B73]">
          <span className="flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5 text-[#3F754E]" />
            <span>NordBrew RBAC Session Token TLS 1.3</span>
          </span>
          <span className="font-mono">Audit Baseline: $115,547.88</span>
        </div>
      </div>
    </div>
  );
};
