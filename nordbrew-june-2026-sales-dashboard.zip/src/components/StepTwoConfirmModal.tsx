import React from 'react';
import { CheckCircle2, ShieldCheck, X, Coffee, Sun } from 'lucide-react';

interface StepTwoConfirmModalProps {
  isOpen: boolean;
  onClose: () => void;
  validCount: number;
  netRevenue: number;
}

export const StepTwoConfirmModal: React.FC<StepTwoConfirmModalProps> = ({
  isOpen,
  onClose,
  validCount,
  netRevenue,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#2D231E]/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white border border-[#EAE3D8] rounded-2xl max-w-lg w-full shadow-2xl overflow-hidden p-6 relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-lg text-[#A8988C] hover:text-[#2D231E] hover:bg-[#FAF7F2] transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center space-x-3 mb-4">
          <div className="w-10 h-10 rounded-xl bg-[#F5EDE4] border border-[#E8DACB] flex items-center justify-center text-[#8C5338]">
            <Coffee className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-[#B86B43] font-mono">
              NordBrew Pipeline Audit
            </span>
            <h3 className="text-lg font-bold text-[#2D231E]">Step 2 & Cozy Café Aesthetic Active</h3>
          </div>
        </div>

        <p className="text-xs text-[#7A6A60] leading-relaxed mb-5">
          All Step 2 user interface and analytics enhancements are active with a warm, cozy café aesthetic inspired by modern lifestyle tracking apps, while maintaining strict accounting reconciliation.
        </p>

        {/* Audit Details */}
        <div className="bg-[#FAF7F2] border border-[#EAE3D8] rounded-xl p-4 space-y-3 font-mono text-xs mb-5">
          <div className="flex justify-between items-center pb-2 border-b border-[#F0EAE1]">
            <span className="text-[#7A6A60] font-sans">Theme & Aesthetic:</span>
            <span className="text-[#2D231E] font-bold flex items-center gap-1 font-sans">
              <Sun className="w-3.5 h-3.5 text-[#B86B43]" /> Warm Cream & Terracotta Café Vibe
            </span>
          </div>
          <div className="flex justify-between items-center pb-2 border-b border-[#F0EAE1]">
            <span className="text-[#7A6A60] font-sans">Product Summary & Pivot:</span>
            <span className="text-[#487A53] font-bold font-sans">
              Active (Grouped by Product & Category with Minimalist Icons)
            </span>
          </div>
          <div className="flex justify-between items-center pb-2 border-b border-[#F0EAE1]">
            <span className="text-[#7A6A60] font-sans">Input Protection:</span>
            <span className="text-[#487A53] font-bold font-sans">
              Minus signs rejected • Zero-safe state active
            </span>
          </div>
          <div className="flex justify-between items-center pb-2 border-b border-[#F0EAE1]">
            <span className="text-[#7A6A60] font-sans">Valid Transaction Rows:</span>
            <span className="text-[#2D231E] font-bold">{validCount.toLocaleString('en-US')} rows (Exact target)</span>
          </div>
          <div className="flex justify-between items-center pb-2 border-b border-[#F0EAE1]">
            <span className="text-[#7A6A60] font-sans">June Net Revenue Total:</span>
            <span className="text-[#B86B43] font-bold">${netRevenue.toLocaleString('en-US', { minimumFractionDigits: 2 })}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-[#7A6A60] font-sans">Cashier Column:</span>
            <span className="text-[#C2584A] line-through">Dropped completely</span>
          </div>
        </div>

        <div className="p-3.5 rounded-xl bg-[#EEF4EE] border border-[#D4E4D4] text-[#487A53] text-xs flex items-center space-x-2.5 mb-6">
          <CheckCircle2 className="w-5 h-5 text-[#487A53] shrink-0" />
          <span>
            <strong className="text-[#2D231E]">Reconciled & Protected!</strong> Ready for executive review and operational planning.
          </span>
        </div>

        <button
          onClick={onClose}
          className="w-full py-2.5 px-4 rounded-xl bg-[#B86B43] hover:bg-[#A35933] text-white font-semibold text-xs transition-all shadow-xs cursor-pointer"
        >
          Return to Dashboard
        </button>
      </div>
    </div>
  );
};
