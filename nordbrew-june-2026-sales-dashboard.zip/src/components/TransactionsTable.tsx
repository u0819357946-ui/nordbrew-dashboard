import React, { useState, useMemo } from 'react';
import { 
  Search, 
  ChevronLeft, 
  ChevronRight, 
  ArrowUpDown, 
  ArrowUp, 
  ArrowDown, 
  UserX, 
  X, 
  RotateCcw, 
  AlertCircle,
  Lock
} from 'lucide-react';
import { SalesRecord, UserProfile } from '../types';
import { getProductVisual } from '../utils/productIcons';

interface TransactionsTableProps {
  records: SalesRecord[];
  currentUser?: UserProfile | null;
}

type SortField = 'date' | 'transactionId' | 'cafe' | 'product' | 'units' | 'netRevenue' | 'category' | 'channel';
type SortOrder = 'asc' | 'desc';

export const TransactionsTable: React.FC<TransactionsTableProps> = ({ records, currentUser }) => {
  const isManager = currentUser?.role === 'manager';
  const assignedCafe = currentUser?.assignedCafe || 'all';

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCafe, setSelectedCafe] = useState<string>(isManager ? assignedCafe : 'all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedChannel, setSelectedChannel] = useState<string>('all');
  const [sortField, setSortField] = useState<SortField>('date');
  const [sortOrder, setSortOrder] = useState<SortOrder>('asc');
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 20;

  React.useEffect(() => {
    if (currentUser?.role === 'manager' && currentUser.assignedCafe) {
      setSelectedCafe(currentUser.assignedCafe);
    } else if (currentUser?.role === 'admin') {
      setSelectedCafe('all');
    }
  }, [currentUser]);


  // Filter options
  const cafes = useMemo(() => Array.from(new Set(records.map((r) => r.cafe))).sort(), [records]);
  const categories = useMemo(() => Array.from(new Set(records.map((r) => r.category))).sort(), [records]);
  const channels = useMemo(() => Array.from(new Set(records.map((r) => r.channel))).sort(), [records]);

  // Reject minus sign / negative input
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const rawVal = e.target.value;
    const sanitized = rawVal.replace(/-/g, '').replace(/[^\w\s.,&]/g, '');
    setSearchTerm(sanitized);
    setCurrentPage(1);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === '-' || e.key === 'Subtract') {
      e.preventDefault();
    }
  };

  const handleResetFilters = () => {
    setSearchTerm('');
    setSelectedCafe('all');
    setSelectedCategory('all');
    setSelectedChannel('all');
    setCurrentPage(1);
  };

  // Filtering & Sorting
  const filteredRecords = useMemo(() => {
    const cleanSearch = searchTerm.trim().toLowerCase();

    return records
      .filter((r) => {
        const matchesSearch =
          cleanSearch === '' ||
          r.transactionId.toLowerCase().includes(cleanSearch) ||
          r.product.toLowerCase().includes(cleanSearch) ||
          r.cafe.toLowerCase().includes(cleanSearch);

        const matchesCafe = selectedCafe === 'all' || r.cafe === selectedCafe;
        const matchesCategory = selectedCategory === 'all' || r.category === selectedCategory;
        const matchesChannel = selectedChannel === 'all' || r.channel === selectedChannel;

        return matchesSearch && matchesCafe && matchesCategory && matchesChannel;
      })
      .sort((a, b) => {
        let valA = a[sortField];
        let valB = b[sortField];

        if (typeof valA === 'string') {
          return sortOrder === 'asc'
            ? (valA as string).localeCompare(valB as string)
            : (valB as string).localeCompare(valA as string);
        } else {
          return sortOrder === 'asc'
            ? (valA as number) - (valB as number)
            : (valB as number) - (valA as number);
        }
      });
  }, [records, searchTerm, selectedCafe, selectedCategory, selectedChannel, sortField, sortOrder]);

  const totalPages = Math.max(1, Math.ceil(filteredRecords.length / pageSize));
  const paginatedRecords = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredRecords.slice(start, start + pageSize);
  }, [filteredRecords, currentPage, pageSize]);

  const toggleSort = (field: SortField) => {
    if (sortField === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortOrder('desc');
    }
    setCurrentPage(1);
  };

  const renderSortIcon = (field: SortField) => {
    if (sortField !== field) return <ArrowUpDown className="w-3.5 h-3.5 text-[#A8988C]" />;
    return sortOrder === 'asc' ? (
      <ArrowUp className="w-3.5 h-3.5 text-[#B86B43] font-bold" />
    ) : (
      <ArrowDown className="w-3.5 h-3.5 text-[#B86B43] font-bold" />
    );
  };

  const isDefault = searchTerm === '' && selectedCafe === 'all' && selectedCategory === 'all' && selectedChannel === 'all';

  return (
    <div className="bg-white border border-[#EAE3D8] rounded-2xl shadow-sm shadow-[#75523F]/5 overflow-hidden">
      {/* Controls & Filter Bar */}
      <div className="p-5 border-b border-[#F0EAE1] flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5 flex-wrap">
            <h3 className="text-sm font-bold text-[#2D231E] uppercase tracking-wider">
              Audited POS Transactions Explorer
            </h3>
            <span className="text-xs font-mono font-semibold text-[#8C5338] bg-[#F5EDE4] border border-[#E8DACB] px-2.5 py-0.5 rounded-full">
              {filteredRecords.length.toLocaleString('en-US')} of {records.length.toLocaleString('en-US')} rows
            </span>
          </div>
          <p className="text-xs text-[#7A6A60] mt-1 flex items-center gap-1.5 flex-wrap">
            <span className="inline-flex items-center gap-1 text-[#8C5338] bg-[#F5EDE4] border border-[#E8DACB] px-2 py-0.5 rounded-md text-[10px] font-semibold">
              <UserX className="w-3 h-3 text-[#B86B43]" /> Rule 4: Cashier column dropped
            </span>
            <span>• Title rows 1-3 skipped • 4 Subtotals & Grand Total excluded</span>
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          {/* Search Box with Minus Rejection */}
          <div className="relative min-w-[200px]">
            <Search className="w-4 h-4 text-[#A8988C] absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search product, ID, café..."
              value={searchTerm}
              onChange={handleSearchChange}
              onKeyDown={handleKeyDown}
              className="w-full bg-[#FAF7F2] border border-[#EAE3D8] rounded-xl pl-9 pr-7 py-1.5 text-xs text-[#2D231E] placeholder-[#A8988C] focus:outline-none focus:border-[#B86B43] focus:bg-white transition-colors"
            />
            {searchTerm && (
              <button
                onClick={() => setSearchTerm('')}
                className="absolute right-2 top-1/2 -translate-y-1/2 text-[#A8988C] hover:text-[#2D231E]"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Café Filter or Locked Role */}
          {isManager ? (
            <div className="bg-[#FAF7F2] border border-[#B86B43]/30 rounded-xl px-2.5 py-1.5 text-xs text-[#2D231E] font-medium shadow-2xs flex items-center gap-1.5">
              <Lock className="w-3 h-3 text-[#B86B43]" />
              <span>{currentUser?.assignedCafe}</span>
            </div>
          ) : (
            <select
              value={selectedCafe}
              onChange={(e) => {
                setSelectedCafe(e.target.value);
                setCurrentPage(1);
              }}
              className="bg-[#FAF7F2] border border-[#EAE3D8] rounded-xl px-2.5 py-1.5 text-xs text-[#2D231E] font-medium focus:outline-none focus:border-[#B86B43] shadow-2xs"
            >
              <option value="all">All Cafés ({cafes.length})</option>
              {cafes.map((c) => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
          )}

          {/* Category Filter */}
          <select
            value={selectedCategory}
            onChange={(e) => {
              setSelectedCategory(e.target.value);
              setCurrentPage(1);
            }}
            className="bg-[#FAF7F2] border border-[#EAE3D8] rounded-xl px-2.5 py-1.5 text-xs text-[#2D231E] font-medium focus:outline-none focus:border-[#B86B43] shadow-2xs"
          >
            <option value="all">All Categories ({categories.length})</option>
            {categories.map((c) => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>

          {/* Channel Filter */}
          <select
            value={selectedChannel}
            onChange={(e) => {
              setSelectedChannel(e.target.value);
              setCurrentPage(1);
            }}
            className="bg-[#FAF7F2] border border-[#EAE3D8] rounded-xl px-2.5 py-1.5 text-xs text-[#2D231E] font-medium focus:outline-none focus:border-[#B86B43] shadow-2xs"
          >
            <option value="all">All Channels ({channels.length})</option>
            {channels.map((ch) => (
              <option key={ch} value={ch}>{ch}</option>
            ))}
          </select>

          {!isDefault && (
            <button
              onClick={handleResetFilters}
              className="p-1.5 rounded-xl bg-[#F7F2EB] hover:bg-[#EFE7DC] text-[#5C4A3E] hover:text-[#2D231E] transition-colors cursor-pointer border border-[#EAE3D8]"
              title="Reset transaction filters to default"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Table Content */}
      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs text-[#2D231E]">
          <thead className="bg-[#FAF7F2] text-[#5C4A3E] text-[11px] uppercase tracking-wider font-semibold border-b border-[#EAE3D8]">
            <tr>
              <th
                onClick={() => toggleSort('date')}
                className="py-3 px-4 cursor-pointer hover:text-[#2D231E] transition-colors"
              >
                <div className="flex items-center gap-1.5">
                  <span>Date</span>
                  {renderSortIcon('date')}
                </div>
              </th>
              <th
                onClick={() => toggleSort('cafe')}
                className="py-3 px-4 cursor-pointer hover:text-[#2D231E] transition-colors"
              >
                <div className="flex items-center gap-1.5">
                  <span>Café</span>
                  {renderSortIcon('cafe')}
                </div>
              </th>
              <th
                onClick={() => toggleSort('product')}
                className="py-3 px-4 cursor-pointer hover:text-[#2D231E] transition-colors"
              >
                <div className="flex items-center gap-1.5">
                  <span>Product</span>
                  {renderSortIcon('product')}
                </div>
              </th>
              <th
                onClick={() => toggleSort('category')}
                className="py-3 px-4 cursor-pointer hover:text-[#2D231E] transition-colors"
              >
                <div className="flex items-center gap-1.5">
                  <span>Category</span>
                  {renderSortIcon('category')}
                </div>
              </th>
              <th
                onClick={() => toggleSort('channel')}
                className="py-3 px-4 cursor-pointer hover:text-[#2D231E] transition-colors"
              >
                <div className="flex items-center gap-1.5">
                  <span>Channel</span>
                  {renderSortIcon('channel')}
                </div>
              </th>
              <th
                onClick={() => toggleSort('units')}
                className="py-3 px-4 cursor-pointer hover:text-[#2D231E] transition-colors text-right"
              >
                <div className="flex items-center justify-end gap-1.5">
                  <span>Units</span>
                  {renderSortIcon('units')}
                </div>
              </th>
              <th className="py-3 px-4 text-right">Unit Price</th>
              <th className="py-3 px-4 text-right">Discount %</th>
              <th className="py-3 px-4 text-right">Unit Cost</th>
              <th
                onClick={() => toggleSort('netRevenue')}
                className="py-3 px-4 cursor-pointer hover:text-[#2D231E] transition-colors text-right"
              >
                <div className="flex items-center justify-end gap-1.5">
                  <span className="text-[#B86B43] font-bold">Net Revenue</span>
                  {renderSortIcon('netRevenue')}
                </div>
              </th>
              <th className="py-3 px-4 text-right">Profit</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#F2ECE3] font-sans">
            {paginatedRecords.length === 0 ? (
              <tr>
                <td colSpan={11} className="py-12 text-center text-[#7A6A60]">
                  <div className="max-w-xs mx-auto text-center space-y-2">
                    <AlertCircle className="w-8 h-8 text-[#B86B43] mx-auto" />
                    <p className="font-bold text-[#2D231E]">No transactions found</p>
                    <p className="text-xs text-[#7A6A60]">
                      Try adjusting the search query or resetting café and category filters.
                    </p>
                    <button
                      onClick={handleResetFilters}
                      className="px-3.5 py-1.5 rounded-xl bg-[#B86B43] hover:bg-[#A35933] text-white text-xs font-semibold cursor-pointer shadow-xs transition-colors"
                    >
                      Reset Filters
                    </button>
                  </div>
                </td>
              </tr>
            ) : (
              paginatedRecords.map((r, idx) => {
                const visual = getProductVisual(r.product, r.category);
                return (
                  <tr
                    key={r.id || idx}
                    className="hover:bg-[#FAF7F2] transition-colors group"
                  >
                    <td className="py-2.5 px-4 font-mono text-[#5C4A3E]">
                      {r.date}
                    </td>
                    <td className="py-2.5 px-4 font-semibold text-[#2D231E]">
                      {r.cafe}
                    </td>
                    <td className="py-2.5 px-4 font-medium text-[#2D231E]">
                      <div className="flex items-center gap-2">
                        <span className={`w-6 h-6 rounded-lg flex items-center justify-center shrink-0 ${visual.bgClass} ${visual.textClass} border ${visual.borderClass}`}>
                          {visual.icon}
                        </span>
                        <span>{r.product}</span>
                      </div>
                    </td>
                    <td className="py-2.5 px-4">
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-medium bg-[#F7F2EB] border border-[#EAE3D8] text-[#5C4A3E]">
                        {r.category}
                      </span>
                    </td>
                    <td className="py-2.5 px-4">
                      <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-medium ${
                        r.channel === 'Dine-in'
                          ? 'bg-[#FDF3E7] text-[#B26B2E] border border-[#F4DEC4]'
                          : 'bg-[#EEF4EE] text-[#487A53] border border-[#D4E4D4]'
                      }`}>
                        {r.channel}
                      </span>
                    </td>
                    <td className="py-2.5 px-4 text-right font-mono text-[#2D231E] font-bold">
                      {r.units}
                    </td>
                    <td className="py-2.5 px-4 text-right font-mono text-[#7A6A60]">
                      ${r.unitPrice.toFixed(2)}
                    </td>
                    <td className="py-2.5 px-4 text-right font-mono">
                      {r.discountPct > 0 ? (
                        <span className="text-[#C2584A] font-semibold">{r.discountPct}%</span>
                      ) : (
                        <span className="text-[#A8988C]">0%</span>
                      )}
                    </td>
                    <td className="py-2.5 px-4 text-right font-mono text-[#7A6A60]">
                      ${r.unitCost.toFixed(2)}
                    </td>
                    <td className="py-2.5 px-4 text-right font-mono font-bold text-[#B86B43] bg-[#FDF9F5]/60 group-hover:bg-[#FDF3E7]/50 transition-colors">
                      ${r.netRevenue.toFixed(2)}
                    </td>
                    <td className="py-2.5 px-4 text-right font-mono font-semibold text-[#487A53]">
                      ${r.profit.toFixed(2)}
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination Footer */}
      <div className="p-4 border-t border-[#F0EAE1] bg-[#FAF7F2] flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-[#5C4A3E]">
        <div>
          Showing{' '}
          <strong className="text-[#2D231E]">
            {filteredRecords.length > 0 ? (currentPage - 1) * pageSize + 1 : 0}
          </strong>{' '}
          to{' '}
          <strong className="text-[#2D231E]">
            {Math.min(currentPage * pageSize, filteredRecords.length)}
          </strong>{' '}
          of <strong className="text-[#B86B43]">{filteredRecords.length.toLocaleString('en-US')}</strong> rows
        </div>

        <div className="flex items-center space-x-1.5">
          <button
            onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
            disabled={currentPage === 1}
            className="p-1.5 rounded-xl border border-[#EAE3D8] bg-white text-[#5C4A3E] hover:text-[#2D231E] disabled:opacity-40 disabled:cursor-not-allowed shadow-2xs"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <span className="px-3 py-1 font-mono text-xs text-[#2D231E]">
            Page {currentPage} of {totalPages}
          </span>
          <button
            onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
            disabled={currentPage === totalPages}
            className="p-1.5 rounded-xl border border-[#EAE3D8] bg-white text-[#5C4A3E] hover:text-[#2D231E] disabled:opacity-40 disabled:cursor-not-allowed shadow-2xs"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
