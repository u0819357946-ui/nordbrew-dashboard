import React, { useMemo } from 'react';
import { TrendingUp, BarChart3, PieChart, Award, Coffee, Store, Sparkles } from 'lucide-react';
import { SalesRecord } from '../types';
import { getProductVisual } from '../utils/productIcons';

interface SalesChartsProps {
  records: SalesRecord[];
}

export const SalesCharts: React.FC<SalesChartsProps> = ({ records }) => {
  // Cafe breakdown
  const cafeData = useMemo(() => {
    const map = new Map<string, number>();
    records.forEach((r) => {
      map.set(r.cafe, (map.get(r.cafe) || 0) + r.netRevenue);
    });
    return Array.from(map.entries())
      .map(([cafe, revenue]) => ({ cafe, revenue }))
      .sort((a, b) => b.revenue - a.revenue);
  }, [records]);

  // Category breakdown
  const categoryData = useMemo(() => {
    const map = new Map<string, number>();
    records.forEach((r) => {
      map.set(r.category, (map.get(r.category) || 0) + r.netRevenue);
    });
    return Array.from(map.entries())
      .map(([category, revenue]) => ({ category, revenue }))
      .sort((a, b) => b.revenue - a.revenue);
  }, [records]);

  // Channel breakdown
  const channelData = useMemo(() => {
    const map = new Map<string, number>();
    records.forEach((r) => {
      map.set(r.channel, (map.get(r.channel) || 0) + r.netRevenue);
    });
    return Array.from(map.entries())
      .map(([channel, revenue]) => ({ channel, revenue }))
      .sort((a, b) => b.revenue - a.revenue);
  }, [records]);

  // Top products
  const topProducts = useMemo(() => {
    const map = new Map<string, { revenue: number; units: number; category: string }>();
    records.forEach((r) => {
      const cur = map.get(r.product) || { revenue: 0, units: 0, category: r.category };
      map.set(r.product, {
        revenue: cur.revenue + r.netRevenue,
        units: cur.units + r.units,
        category: r.category,
      });
    });
    return Array.from(map.entries())
      .map(([product, data]) => ({ product, ...data }))
      .sort((a, b) => b.revenue - a.revenue)
      .slice(0, 5);
  }, [records]);

  // Daily revenue trend (June 1 - 30)
  const dailyData = useMemo(() => {
    const map = new Map<string, number>();
    for (let day = 1; day <= 30; day++) {
      const dateStr = `2026-06-${String(day).padStart(2, '0')}`;
      map.set(dateStr, 0);
    }
    records.forEach((r) => {
      map.set(r.date, (map.get(r.date) || 0) + r.netRevenue);
    });
    return Array.from(map.entries()).map(([date, revenue]) => ({
      date,
      day: parseInt(date.split('-')[2], 10),
      revenue,
    }));
  }, [records]);

  const maxDailyRevenue = Math.max(...dailyData.map((d) => d.revenue), 1);
  const totalRevenue = records.reduce((acc, r) => acc + r.netRevenue, 0);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
      {/* 1. Daily Revenue Trend */}
      <div className="bg-white border border-[#EAE3D8] rounded-2xl p-5 sm:p-6 shadow-sm shadow-[#75523F]/5 flex flex-col justify-between">
        <div>
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-2.5">
              <div className="w-8 h-8 rounded-xl bg-[#F5EDE4] border border-[#E8DACB] flex items-center justify-center text-[#8C5338]">
                <TrendingUp className="w-4 h-4" />
              </div>
              <h3 className="text-sm font-bold text-[#2D231E] uppercase tracking-wider">
                Daily Revenue Trajectory (June 1–30, 2026)
              </h3>
            </div>
            <span className="text-[11px] font-mono text-[#7A6A60]">30 Days Audited</span>
          </div>

          {/* Bar Chart with warm terracotta / caramel aesthetic */}
          <div className="h-44 flex items-end gap-1.5 pt-4 pb-2 px-1 border-b border-[#F0EAE1]">
            {dailyData.map((d) => {
              const heightPct = Math.max(8, Math.round((d.revenue / maxDailyRevenue) * 100));
              return (
                <div
                  key={d.date}
                  className="flex-1 flex flex-col items-center group relative h-full justify-end"
                >
                  <div className="absolute -top-9 opacity-0 group-hover:opacity-100 transition-opacity bg-[#2D231E] text-white text-[10px] font-mono py-1 px-2 rounded-lg pointer-events-none whitespace-nowrap z-20 shadow-md">
                    Jun {d.day}: ${d.revenue.toFixed(0)}
                  </div>
                  <div
                    style={{ height: `${heightPct}%` }}
                    className="w-full bg-gradient-to-t from-[#B86B43] via-[#C87D55] to-[#E59A6F] rounded-t-md group-hover:from-[#9E5733] group-hover:to-[#D28C4A] transition-all cursor-pointer"
                  />
                </div>
              );
            })}
          </div>
          <div className="flex justify-between text-[10px] text-[#A8988C] font-mono mt-2.5">
            <span>Jun 1</span>
            <span>Jun 10</span>
            <span>Jun 20</span>
            <span>Jun 30</span>
          </div>
        </div>

        <div className="mt-4 pt-3.5 border-t border-[#F0EAE1] flex items-center justify-between text-xs text-[#5C4A3E]">
          <span>Peak Day: <strong className="text-[#B86B43] font-mono">${maxDailyRevenue.toFixed(2)}</strong></span>
          <span>Daily Average: <strong className="text-[#2D231E] font-mono">${(totalRevenue / 30).toFixed(2)}</strong></span>
        </div>
      </div>

      {/* 2. Café Contribution (Tallinn, Riga, Vilnius, Helsinki) */}
      <div className="bg-white border border-[#EAE3D8] rounded-2xl p-5 sm:p-6 shadow-sm shadow-[#75523F]/5 flex flex-col justify-between">
        <div>
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-2.5">
              <div className="w-8 h-8 rounded-xl bg-[#FDF3E7] border border-[#F4DEC4] flex items-center justify-center text-[#B26B2E]">
                <Store className="w-4 h-4" />
              </div>
              <h3 className="text-sm font-bold text-[#2D231E] uppercase tracking-wider">
                Café Contribution (4 Cities)
              </h3>
            </div>
            <span className="text-[11px] font-mono font-bold text-[#487A53] bg-[#EEF4EE] border border-[#D4E4D4] px-2 py-0.5 rounded-full">
              4 Subtotals Reconciled
            </span>
          </div>

          <div className="space-y-3.5">
            {cafeData.map((c, idx) => {
              const pct = totalRevenue > 0 ? (c.revenue / totalRevenue) * 100 : 0;
              return (
                <div key={c.cafe} className="space-y-1.5">
                  <div className="flex justify-between text-xs">
                    <span className="text-[#2D231E] font-semibold flex items-center gap-2">
                      <span className="text-[10px] font-mono text-[#A8988C]">0{idx + 1}</span>
                      {c.cafe}
                      <span className="text-[10px] text-[#7A6A60] font-mono">
                        (Subtotal: ${c.revenue.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })})
                      </span>
                    </span>
                    <span className="font-mono text-[#2D231E] font-bold">
                      ${c.revenue.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      <span className="text-[10px] text-[#B86B43] font-normal ml-1.5">
                        ({pct.toFixed(1)}%)
                      </span>
                    </span>
                  </div>
                  <div className="h-2.5 w-full bg-[#EFE9DF] rounded-full overflow-hidden">
                    <div
                      style={{ width: `${pct}%` }}
                      className="h-full bg-gradient-to-r from-[#B86B43] to-[#DDA77B] rounded-full"
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="mt-4 pt-3.5 border-t border-[#F0EAE1] text-xs text-[#5C4A3E] flex items-center justify-between">
          <span>Top Revenue Hub: <strong className="text-[#B86B43]">{cafeData[0]?.cafe} ($42,973.77)</strong></span>
          <span>Total Net Revenue: <strong className="text-[#2D231E] font-mono font-bold">${totalRevenue.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</strong></span>
        </div>
      </div>

      {/* 3. Category & Channel Breakdown */}
      <div className="bg-white border border-[#EAE3D8] rounded-2xl p-5 sm:p-6 shadow-sm shadow-[#75523F]/5">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-xl bg-[#EEF4EE] border border-[#D4E4D4] flex items-center justify-center text-[#487A53]">
              <PieChart className="w-4 h-4" />
            </div>
            <h3 className="text-sm font-bold text-[#2D231E] uppercase tracking-wider">
              Category & Channel Performance
            </h3>
          </div>
          <span className="text-[11px] font-mono text-[#7A6A60]">Share of Net Revenue</span>
        </div>

        <div className="grid grid-cols-2 gap-3 mb-4">
          {categoryData.map((c) => {
            const pct = totalRevenue > 0 ? (c.revenue / totalRevenue) * 100 : 0;
            return (
              <div
                key={c.category}
                className="p-3.5 rounded-xl bg-[#FAF7F2] border border-[#EAE3D8] flex flex-col justify-between shadow-2xs"
              >
                <div className="flex justify-between items-start">
                  <span className="text-xs font-bold text-[#2D231E]">{c.category}</span>
                  <span className="text-xs font-bold font-mono text-[#B86B43]">{pct.toFixed(1)}%</span>
                </div>
                <div className="mt-2 text-sm font-bold font-mono text-[#2D231E]">
                  ${c.revenue.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </div>
              </div>
            );
          })}
        </div>

        {/* Channel share pills */}
        <div className="p-3.5 rounded-xl bg-[#FAF7F2] border border-[#EAE3D8] flex items-center justify-around text-xs shadow-2xs">
          {channelData.map((ch) => (
            <div key={ch.channel} className="text-center font-mono">
              <span className="text-[#7A6A60] text-[10px] block font-sans">{ch.channel}</span>
              <span className="text-[#2D231E] font-bold">${ch.revenue.toFixed(2)}</span>
              <span className="text-[#A8988C] text-[10px] ml-1">
                ({((ch.revenue / (totalRevenue || 1)) * 100).toFixed(1)}%)
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* 4. Top 5 Best Sellers with Illustrated Icons */}
      <div className="bg-white border border-[#EAE3D8] rounded-2xl p-5 sm:p-6 shadow-sm shadow-[#75523F]/5">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-xl bg-[#F5EDE4] border border-[#E8DACB] flex items-center justify-center text-[#8C5338]">
              <Award className="w-4 h-4" />
            </div>
            <h3 className="text-sm font-bold text-[#2D231E] uppercase tracking-wider">
              Top 5 Products by Revenue
            </h3>
          </div>
          <span className="text-[11px] font-mono text-[#7A6A60]">June 2026 Volume</span>
        </div>

        <div className="space-y-2.5">
          {topProducts.map((p, idx) => {
            const visual = getProductVisual(p.product, p.category);
            return (
              <div
                key={p.product}
                className="p-3 rounded-xl bg-[#FAF7F2] border border-[#EAE3D8] flex items-center justify-between shadow-2xs hover:border-[#DCCFC0] transition-colors"
              >
                <div className="flex items-center space-x-3">
                  <div className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 ${visual.bgClass} ${visual.textClass} border ${visual.borderClass}`}>
                    {visual.icon}
                  </div>
                  <div>
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs font-mono font-bold text-[#B86B43]">#{idx + 1}</span>
                      <p className="text-xs font-bold text-[#2D231E]">{p.product}</p>
                    </div>
                    <p className="text-[10px] text-[#7A6A60] font-mono">{p.units.toLocaleString()} units sold • {visual.badgeLabel}</p>
                  </div>
                </div>
                <div className="text-right font-mono">
                  <span className="text-xs font-bold text-[#B86B43]">
                    ${p.revenue.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
