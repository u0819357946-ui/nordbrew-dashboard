import React, { useState, useMemo } from 'react';
import { 
  Search, 
  Store, 
  Layers, 
  ChevronDown, 
  ChevronRight, 
  ArrowUpDown, 
  ArrowUp, 
  ArrowDown, 
  Coffee, 
  Calendar, 
  Download, 
  X,
  RotateCcw,
  AlertCircle,
  FolderTree,
  Grid,
  Sparkles,
  CupSoda,
  Cookie,
  Sandwich,
  ShoppingBag,
  Lock
} from 'lucide-react';
import { SalesRecord, UserProfile } from '../types';
import { getProductVisual } from '../utils/productIcons';
import * as XLSX from 'xlsx';

interface ProductSummaryViewProps {
  records: SalesRecord[];
  currentUser?: UserProfile | null;
}


export interface ProductAggregate {
  product: string;
  category: string;
  totalUnits: number;
  totalNetRevenue: number;
  totalGrossAmount: number;
  totalDiscount: number;
  totalCost: number;
  totalProfit: number;
  profitMargin: number;
  avgNetUnitPrice: number;
  catalogUnitPrice: number;
  txCount: number;
  cafeBreakdown: Record<string, { units: number; revenue: number }>;
  channelBreakdown: Record<string, { units: number; revenue: number }>;
  dailyBreakdown: SalesRecord[];
}

export interface CategoryAggregate {
  category: string;
  totalUnits: number;
  totalNetRevenue: number;
  totalGrossAmount: number;
  totalDiscount: number;
  totalProfit: number;
  profitMargin: number;
  products: ProductAggregate[];
}

type SortField = 'netRevenue' | 'units' | 'profit' | 'profitMargin' | 'avgPrice' | 'product';
type SortOrder = 'asc' | 'desc';

export const ProductSummaryView: React.FC<ProductSummaryViewProps> = ({ records, currentUser }) => {
  const isManager = currentUser?.role === 'manager';
  const assignedCafe = currentUser?.assignedCafe || 'all';

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCafe, setSelectedCafe] = useState<string>(isManager ? assignedCafe : 'all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [viewGrouping, setViewGrouping] = useState<'product' | 'category'>('product');
  const [sortField, setSortField] = useState<SortField>('netRevenue');
  const [sortOrder, setSortOrder] = useState<SortOrder>('desc');
  const [expandedProduct, setExpandedProduct] = useState<string | null>(null);
  const [expandedCategory, setExpandedCategory] = useState<string | null>(null);

  // Sync cafe state if currentUser changes
  React.useEffect(() => {
    if (currentUser?.role === 'manager' && currentUser.assignedCafe) {
      setSelectedCafe(currentUser.assignedCafe);
    } else if (currentUser?.role === 'admin') {
      setSelectedCafe('all');
    }
  }, [currentUser]);


  // Available Filter Options
  const cafes = useMemo(() => Array.from(new Set(records.map((r) => r.cafe))).sort(), [records]);
  const categories = useMemo(() => Array.from(new Set(records.map((r) => r.category))).sort(), [records]);

  // Input sanitizer: reject minus signs & negative inputs completely
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const rawVal = e.target.value;
    const sanitized = rawVal.replace(/-/g, '').replace(/[^\w\s.,&]/g, '');
    setSearchTerm(sanitized);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === '-' || e.key === 'Subtract') {
      e.preventDefault();
    }
  };

  // Reset all filters to default
  const handleResetFilters = () => {
    setSearchTerm('');
    setSelectedCafe('all');
    setSelectedCategory('all');
    setSortField('netRevenue');
    setSortOrder('desc');
    setExpandedProduct(null);
  };

  // Is using full default view?
  const isDefaultView = searchTerm === '' && selectedCafe === 'all' && selectedCategory === 'all';

  // Aggregate by Product based on active filters
  const aggregatedProducts: ProductAggregate[] = useMemo(() => {
    const cleanSearch = searchTerm.trim().toLowerCase();

    // 1. Filter raw transactions first by Cafe and Category
    const filteredRecords = records.filter((r) => {
      const matchesCafe = selectedCafe === 'all' || r.cafe === selectedCafe;
      const matchesCategory = selectedCategory === 'all' || r.category === selectedCategory;
      const matchesSearch = cleanSearch === '' || 
        r.product.toLowerCase().includes(cleanSearch) ||
        r.category.toLowerCase().includes(cleanSearch);

      return matchesCafe && matchesCategory && matchesSearch;
    });

    // 2. Group by Product
    const productMap = new Map<string, {
      product: string;
      category: string;
      totalUnits: number;
      totalNetRevenue: number;
      totalGrossAmount: number;
      totalDiscount: number;
      totalCost: number;
      totalProfit: number;
      catalogUnitPrice: number;
      txCount: number;
      cafeBreakdown: Record<string, { units: number; revenue: number }>;
      channelBreakdown: Record<string, { units: number; revenue: number }>;
      dailyBreakdown: SalesRecord[];
    }>();

    for (const r of filteredRecords) {
      if (!productMap.has(r.product)) {
        productMap.set(r.product, {
          product: r.product,
          category: r.category,
          totalUnits: 0,
          totalNetRevenue: 0,
          totalGrossAmount: 0,
          totalDiscount: 0,
          totalCost: 0,
          totalProfit: 0,
          catalogUnitPrice: r.unitPrice,
          txCount: 0,
          cafeBreakdown: {},
          channelBreakdown: {},
          dailyBreakdown: [],
        });
      }

      const item = productMap.get(r.product)!;
      item.totalUnits += r.units;
      item.totalNetRevenue += r.netRevenue;
      item.totalGrossAmount += r.grossAmount;
      item.totalDiscount += r.discount;
      item.totalCost += r.cost;
      item.totalProfit += r.profit;
      item.txCount += 1;
      item.dailyBreakdown.push(r);

      // Cafe breakdown
      if (!item.cafeBreakdown[r.cafe]) {
        item.cafeBreakdown[r.cafe] = { units: 0, revenue: 0 };
      }
      item.cafeBreakdown[r.cafe].units += r.units;
      item.cafeBreakdown[r.cafe].revenue += r.netRevenue;

      // Channel breakdown
      if (!item.channelBreakdown[r.channel]) {
        item.channelBreakdown[r.channel] = { units: 0, revenue: 0 };
      }
      item.channelBreakdown[r.channel].units += r.units;
      item.channelBreakdown[r.channel].revenue += r.netRevenue;
    }

    // 3. Derived metrics & Sort
    const list: ProductAggregate[] = Array.from(productMap.values()).map((p) => {
      const avgNetUnitPrice = p.totalUnits > 0 ? p.totalNetRevenue / p.totalUnits : 0;
      const profitMargin = p.totalNetRevenue > 0 ? (p.totalProfit / p.totalNetRevenue) * 100 : 0;

      p.dailyBreakdown.sort((a, b) => a.date.localeCompare(b.date));

      return {
        ...p,
        totalNetRevenue: Math.round(p.totalNetRevenue * 100) / 100,
        totalGrossAmount: Math.round(p.totalGrossAmount * 100) / 100,
        totalDiscount: Math.round(p.totalDiscount * 100) / 100,
        totalCost: Math.round(p.totalCost * 100) / 100,
        totalProfit: Math.round(p.totalProfit * 100) / 100,
        avgNetUnitPrice: Math.round(avgNetUnitPrice * 100) / 100,
        profitMargin: Math.round(profitMargin * 10) / 10,
      };
    });

    return list.sort((a, b) => {
      let valA: number | string = 0;
      let valB: number | string = 0;

      switch (sortField) {
        case 'netRevenue':
          valA = a.totalNetRevenue;
          valB = b.totalNetRevenue;
          break;
        case 'units':
          valA = a.totalUnits;
          valB = b.totalUnits;
          break;
        case 'profit':
          valA = a.totalProfit;
          valB = b.totalProfit;
          break;
        case 'profitMargin':
          valA = a.profitMargin;
          valB = b.profitMargin;
          break;
        case 'avgPrice':
          valA = a.avgNetUnitPrice;
          valB = b.avgNetUnitPrice;
          break;
        case 'product':
          valA = a.product;
          valB = b.product;
          break;
      }

      if (typeof valA === 'string') {
        return sortOrder === 'asc'
          ? (valA as string).localeCompare(valB as string)
          : (valB as string).localeCompare(valA as string);
      } else {
        return sortOrder === 'asc'
          ? (valA as number) - (valB as number)
          : (valB as number) - (valA as number);
      }
    });
  }, [records, selectedCafe, selectedCategory, searchTerm, sortField, sortOrder]);

  // Category-level aggregation
  const categoryAggregates: CategoryAggregate[] = useMemo(() => {
    const catMap = new Map<string, {
      category: string;
      totalUnits: number;
      totalNetRevenue: number;
      totalGrossAmount: number;
      totalDiscount: number;
      totalProfit: number;
      products: ProductAggregate[];
    }>();

    for (const p of aggregatedProducts) {
      if (!catMap.has(p.category)) {
        catMap.set(p.category, {
          category: p.category,
          totalUnits: 0,
          totalNetRevenue: 0,
          totalGrossAmount: 0,
          totalDiscount: 0,
          totalProfit: 0,
          products: [],
        });
      }
      const cat = catMap.get(p.category)!;
      cat.totalUnits += p.totalUnits;
      cat.totalNetRevenue += p.totalNetRevenue;
      cat.totalGrossAmount += p.totalGrossAmount;
      cat.totalDiscount += p.totalDiscount;
      cat.totalProfit += p.totalProfit;
      cat.products.push(p);
    }

    return Array.from(catMap.values())
      .map((c) => ({
        ...c,
        totalNetRevenue: Math.round(c.totalNetRevenue * 100) / 100,
        profitMargin: c.totalNetRevenue > 0 ? Math.round((c.totalProfit / c.totalNetRevenue) * 1000) / 10 : 0,
      }))
      .sort((a, b) => b.totalNetRevenue - a.totalNetRevenue);
  }, [aggregatedProducts]);

  // Overall totals for the active filter selection
  const selectionTotals = useMemo(() => {
    if (aggregatedProducts.length === 0) {
      return {
        netRevenue: 0,
        units: 0,
        profit: 0,
        gross: 0,
        discount: 0,
        margin: 0,
      };
    }

    const netRevenue = aggregatedProducts.reduce((acc, p) => acc + p.totalNetRevenue, 0);
    const units = aggregatedProducts.reduce((acc, p) => acc + p.totalUnits, 0);
    const profit = aggregatedProducts.reduce((acc, p) => acc + p.totalProfit, 0);
    const gross = aggregatedProducts.reduce((acc, p) => acc + p.totalGrossAmount, 0);
    const discount = aggregatedProducts.reduce((acc, p) => acc + p.totalDiscount, 0);
    const margin = netRevenue > 0 ? (profit / netRevenue) * 100 : 0;

    return {
      netRevenue: Math.round(netRevenue * 100) / 100,
      units,
      profit: Math.round(profit * 100) / 100,
      gross: Math.round(gross * 100) / 100,
      discount: Math.round(discount * 100) / 100,
      margin: Math.round(margin * 10) / 10,
    };
  }, [aggregatedProducts]);

  const toggleSort = (field: SortField) => {
    if (sortField === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortOrder('desc');
    }
  };

  const renderSortIcon = (field: SortField) => {
    if (sortField !== field) return <ArrowUpDown className="w-3.5 h-3.5 text-[#A8988C]" />;
    return sortOrder === 'asc' ? (
      <ArrowUp className="w-3.5 h-3.5 text-[#B86B43] font-bold" />
    ) : (
      <ArrowDown className="w-3.5 h-3.5 text-[#B86B43] font-bold" />
    );
  };

  const handleExportPivot = () => {
    const dataToExport = aggregatedProducts.map((p) => ({
      'Product': p.product,
      'Category': p.category,
      'Total Units Sold': p.totalUnits,
      'Catalog Price ($)': p.catalogUnitPrice,
      'Avg Realized Price ($)': p.avgNetUnitPrice,
      'Gross Revenue ($)': p.totalGrossAmount,
      'Discounts Given ($)': p.totalDiscount,
      'Total Net Revenue ($)': p.totalNetRevenue,
      'Gross Profit ($)': p.totalProfit,
      'Profit Margin (%)': `${p.profitMargin}%`,
      'Transactions Count': p.txCount,
      'Café Scope': selectedCafe === 'all' ? 'All Locations' : selectedCafe,
    }));

    const ws = XLSX.utils.json_to_sheet(dataToExport);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Product_Pivot_Summary');
    XLSX.writeFile(wb, `NordBrew_June2026_Product_Summary_${selectedCafe}.xlsx`);
  };

  return (
    <div className="space-y-6">
      {/* Top Aggregation Header & Controls */}
      <div className="bg-white border border-[#EAE3D8] rounded-2xl p-5 sm:p-6 shadow-sm shadow-[#75523F]/5">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-[#F0EAE1]">
          <div>
            <div className="flex items-center gap-2.5 flex-wrap">
              <div className="w-9 h-9 rounded-xl bg-[#F5EDE4] border border-[#E8DACB] flex items-center justify-center text-[#8C5338] shadow-xs">
                <Coffee className="w-4 h-4" />
              </div>
              <h2 className="text-lg font-bold text-[#2D231E] tracking-tight">
                Product & Category Summary
              </h2>
              {isDefaultView ? (
                <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-[#EEF4EE] text-[#487A53] border border-[#D4E4D4]">
                  Default View Active ($115,547.88 Reconciled)
                </span>
              ) : (
                <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-[#FDF3E7] text-[#B26B2E] border border-[#F4DEC4]">
                  Filtered: {aggregatedProducts.length} Products
                </span>
              )}
            </div>
            <p className="text-xs text-[#7A6A60] mt-1.5">
              Monthly totals rolled up by Product and Category across June 2026. Select any row to inspect daily POS transactions.
            </p>
          </div>

          <div className="flex items-center gap-2.5 self-start lg:self-auto">
            {/* View Grouping Toggle: Product vs Category */}
            <div className="bg-[#F7F2EB] p-1 rounded-xl flex items-center text-xs font-medium border border-[#EAE3D8]">
              <button
                onClick={() => setViewGrouping('product')}
                className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
                  viewGrouping === 'product'
                    ? 'bg-white text-[#2D231E] shadow-xs font-bold border border-[#E5DDD2]'
                    : 'text-[#7A6A60] hover:text-[#2D231E]'
                }`}
              >
                <Grid className="w-3.5 h-3.5 text-[#B86B43]" />
                <span>By Product ({aggregatedProducts.length})</span>
              </button>
              <button
                onClick={() => setViewGrouping('category')}
                className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
                  viewGrouping === 'category'
                    ? 'bg-white text-[#2D231E] shadow-xs font-bold border border-[#E5DDD2]'
                    : 'text-[#7A6A60] hover:text-[#2D231E]'
                }`}
              >
                <FolderTree className="w-3.5 h-3.5 text-[#6D8A74]" />
                <span>By Category ({categoryAggregates.length})</span>
              </button>
            </div>

            <button
              onClick={handleExportPivot}
              className="px-3.5 py-1.5 rounded-xl bg-white hover:bg-[#FAF7F2] border border-[#EAE3D8] text-xs font-semibold text-[#5C4A3E] hover:text-[#2D231E] flex items-center gap-1.5 transition-all cursor-pointer shadow-xs"
              title="Export aggregated pivot summary to Excel"
            >
              <Download className="w-3.5 h-3.5 text-[#B86B43]" />
              <span>Export</span>
            </button>
          </div>
        </div>

        {/* Filter Controls Row with Strict Input Sanitization */}
        <div className="pt-4 flex flex-col md:flex-row md:items-center justify-between gap-3.5">
          <div className="flex flex-wrap items-center gap-2.5 flex-1">
            {/* Search Input with Minus Protection */}
            <div className="relative min-w-[240px] flex-1 sm:flex-initial">
              <Search className="w-4 h-4 text-[#A8988C] absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search product (e.g. 'Cappuccino', 'Bun')..."
                value={searchTerm}
                onChange={handleSearchChange}
                onKeyDown={handleKeyDown}
                className="w-full bg-[#FAF7F2] border border-[#EAE3D8] rounded-xl pl-9 pr-8 py-2 text-xs text-[#2D231E] placeholder-[#A8988C] focus:outline-none focus:border-[#B86B43] focus:bg-white transition-colors"
              />
              {searchTerm && (
                <button
                  onClick={() => setSearchTerm('')}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[#A8988C] hover:text-[#2D231E]"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {/* Café Filter Dropdown or Locked Scope */}
            {isManager ? (
              <div className="flex items-center gap-1.5 bg-[#FAF7F2] border border-[#B86B43]/30 rounded-xl px-3 py-1.5 shadow-2xs">
                <Lock className="w-3.5 h-3.5 text-[#B86B43]" />
                <span className="text-[11px] text-[#7A6A60] font-medium">Assigned Café:</span>
                <span className="text-xs text-[#2D231E] font-bold">{currentUser?.assignedCafe}</span>
              </div>
            ) : (
              <div className="flex items-center gap-1.5 bg-[#FAF7F2] border border-[#EAE3D8] rounded-xl px-3 py-1.5 shadow-2xs">
                <Store className="w-3.5 h-3.5 text-[#B86B43]" />
                <span className="text-[11px] text-[#7A6A60] font-medium">Café:</span>
                <select
                  value={selectedCafe}
                  onChange={(e) => setSelectedCafe(e.target.value)}
                  className="bg-transparent text-xs text-[#2D231E] font-semibold focus:outline-none cursor-pointer pr-1"
                >
                  <option value="all">All Cafés (4 Locations)</option>
                  {cafes.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
              </div>
            )}

            {/* Category Filter Dropdown */}
            <div className="flex items-center gap-1.5 bg-[#FAF7F2] border border-[#EAE3D8] rounded-xl px-3 py-1.5 shadow-2xs">
              <Layers className="w-3.5 h-3.5 text-[#5C8563]" />
              <span className="text-[11px] text-[#7A6A60] font-medium">Category:</span>
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="bg-transparent text-xs text-[#2D231E] font-semibold focus:outline-none cursor-pointer pr-1"
              >
                <option value="all">All Categories ({categories.length})</option>
                {categories.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>

            {/* Reset Button */}
            {!isDefaultView && (
              <button
                onClick={handleResetFilters}
                className="px-3 py-1.5 rounded-xl bg-[#F7F2EB] hover:bg-[#EFE7DC] text-[#5C4A3E] text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer border border-[#EAE3D8]"
                title="Reset all filters to default full view"
              >
                <RotateCcw className="w-3.5 h-3.5 text-[#7A6A60]" />
                <span>Reset Filters</span>
              </button>
            )}
          </div>

          {/* Quick Filter Presets */}
          <div className="flex items-center gap-1.5 overflow-x-auto text-[11px]">
            {isManager ? (
              <div className="flex items-center gap-1.5 text-[11px]">
                <span className="text-[#A8988C] font-medium whitespace-nowrap">Access:</span>
                <span className="px-2.5 py-1 rounded-lg bg-[#B86B43] text-white font-semibold shadow-xs flex items-center gap-1">
                  <Lock className="w-3 h-3 text-white" />
                  <span>{currentUser?.assignedCafe} Scoped View</span>
                </span>
              </div>
            ) : (
              <>
                <span className="text-[#A8988C] font-medium whitespace-nowrap">Cafés:</span>
                <button
                  onClick={() => { setSelectedCafe('all'); setSelectedCategory('all'); setSearchTerm(''); }}
                  className={`px-2.5 py-1 rounded-lg transition-colors cursor-pointer whitespace-nowrap ${
                    selectedCafe === 'all' && selectedCategory === 'all' && !searchTerm
                      ? 'bg-[#B86B43] text-white font-semibold shadow-xs'
                      : 'bg-[#F7F2EB] text-[#5C4A3E] hover:text-[#2D231E] border border-[#EAE3D8]'
                  }`}
                >
                  All Hubs
                </button>
                {cafes.map((c) => (
                  <button
                    key={c}
                    onClick={() => setSelectedCafe(c)}
                    className={`px-2.5 py-1 rounded-lg transition-colors cursor-pointer whitespace-nowrap ${
                      selectedCafe === c
                        ? 'bg-[#B86B43] text-white font-semibold shadow-xs'
                        : 'bg-[#F7F2EB] text-[#5C4A3E] hover:text-[#2D231E] border border-[#EAE3D8]'
                    }`}
                  >
                    {c}
                  </button>
                ))}
              </>
            )}
          </div>
        </div>


        {/* Dynamic Aggregated Banner for current selection */}
        <div className="mt-5 pt-4 border-t border-[#F0EAE1] grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
          <div className="bg-[#FAF7F2] border border-[#EAE3D8] rounded-xl p-3.5 shadow-2xs">
            <span className="text-[10px] uppercase font-bold text-[#7A6A60] block tracking-wider">
              {selectedCafe === 'all' ? 'All Cafés Net Revenue' : `${selectedCafe} Net Revenue`}
            </span>
            <span className="text-base font-bold font-mono text-[#B86B43]">
              ${selectionTotals.netRevenue.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </span>
          </div>

          <div className="bg-[#FAF7F2] border border-[#EAE3D8] rounded-xl p-3.5 shadow-2xs">
            <span className="text-[10px] uppercase font-bold text-[#7A6A60] block tracking-wider">
              Total Units Sold
            </span>
            <span className="text-base font-bold font-mono text-[#2D231E]">
              {selectionTotals.units.toLocaleString('en-US')} units
            </span>
          </div>

          <div className="bg-[#FAF7F2] border border-[#EAE3D8] rounded-xl p-3.5 shadow-2xs">
            <span className="text-[10px] uppercase font-bold text-[#7A6A60] block tracking-wider">
              Gross Profit
            </span>
            <span className="text-base font-bold font-mono text-[#487A53]">
              ${selectionTotals.profit.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              <span className="text-[10px] text-[#7A6A60] font-normal ml-1">({selectionTotals.margin}%)</span>
            </span>
          </div>

          <div className="bg-[#FAF7F2] border border-[#EAE3D8] rounded-xl p-3.5 shadow-2xs">
            <span className="text-[10px] uppercase font-bold text-[#7A6A60] block tracking-wider">
              Average Net Realized Price
            </span>
            <span className="text-base font-bold font-mono text-[#2D231E]">
              ${selectionTotals.units > 0 ? (selectionTotals.netRevenue / selectionTotals.units).toFixed(2) : '0.00'} / unit
            </span>
          </div>
        </div>
      </div>

      {/* No-Data State Handling: Zeroed metrics and safe card */}
      {aggregatedProducts.length === 0 ? (
        <div className="bg-white border border-[#EAE3D8] rounded-2xl p-10 text-center shadow-sm">
          <div className="w-12 h-12 rounded-2xl bg-[#FDF3E7] border border-[#F4DEC4] text-[#B26B2E] flex items-center justify-center mx-auto mb-3">
            <AlertCircle className="w-6 h-6" />
          </div>
          <h3 className="text-base font-bold text-[#2D231E]">No Matching Product Data</h3>
          <p className="text-xs text-[#7A6A60] max-w-md mx-auto mt-1 mb-4 leading-relaxed">
            No transactions found for the current query{' '}
            {searchTerm && <strong className="text-[#2D231E]">"{searchTerm}"</strong>}
            {selectedCafe !== 'all' && <span> in café <strong className="text-[#2D231E]">{selectedCafe}</strong></span>}
            {selectedCategory !== 'all' && <span> within category <strong className="text-[#2D231E]">{selectedCategory}</strong></span>}.
          </p>

          <div className="inline-flex items-center gap-3">
            <button
              onClick={handleResetFilters}
              className="px-4 py-2 rounded-xl bg-[#B86B43] hover:bg-[#A35933] text-white text-xs font-semibold flex items-center gap-2 shadow-xs transition-colors cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset Filters to Full View ($115,547.88)</span>
            </button>
          </div>
        </div>
      ) : viewGrouping === 'category' ? (
        /* Category-Level Aggregated View */
        <div className="space-y-4">
          {categoryAggregates.map((cat) => {
            const isCatExpanded = expandedCategory === cat.category;
            const catShare = selectionTotals.netRevenue > 0
              ? (cat.totalNetRevenue / selectionTotals.netRevenue) * 100
              : 0;

            return (
              <div key={cat.category} className="bg-white border border-[#EAE3D8] rounded-2xl shadow-sm shadow-[#75523F]/5 overflow-hidden">
                <div
                  onClick={() => setExpandedCategory(isCatExpanded ? null : cat.category)}
                  className="p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 cursor-pointer hover:bg-[#FAF7F2] transition-colors"
                >
                  <div className="flex items-center space-x-3.5">
                    <div className="w-10 h-10 rounded-xl bg-[#F7F2EB] border border-[#EAE3D8] flex items-center justify-center text-[#5C4A3E] font-bold shadow-2xs">
                      {isCatExpanded ? <ChevronDown className="w-4 h-4 text-[#B86B43]" /> : <ChevronRight className="w-4 h-4" />}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="text-base font-bold text-[#2D231E]">{cat.category}</h3>
                        <span className="text-xs font-medium px-2.5 py-0.5 rounded-full bg-[#F7F2EB] text-[#5C4A3E] border border-[#EAE3D8]">
                          {cat.products.length} Products
                        </span>
                      </div>
                      <p className="text-xs text-[#7A6A60] mt-0.5">
                        {cat.totalUnits.toLocaleString('en-US')} total units sold across June 2026
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-6 font-mono text-right">
                    <div>
                      <span className="text-[10px] text-[#A8988C] block font-sans uppercase">Units</span>
                      <span className="text-sm font-bold text-[#2D231E]">{cat.totalUnits.toLocaleString('en-US')}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-[#A8988C] block font-sans uppercase">Share</span>
                      <span className="text-sm font-bold text-[#7A6A60]">{catShare.toFixed(1)}%</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-[#A8988C] block font-sans uppercase">Net Revenue</span>
                      <span className="text-base font-bold text-[#B86B43]">
                        ${cat.totalNetRevenue.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Collapsible Product List under this Category */}
                {isCatExpanded && (
                  <div className="border-t border-[#F0EAE1] bg-[#FAF7F2] p-5">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
                      {cat.products.map((p) => {
                        const visual = getProductVisual(p.product, p.category);
                        return (
                          <div key={p.product} className="p-4 rounded-xl bg-white border border-[#EAE3D8] shadow-xs space-y-2.5 hover:border-[#DCCFC0] transition-all">
                            <div className="flex items-center gap-3">
                              <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${visual.bgClass} ${visual.textClass} border ${visual.borderClass} shadow-2xs`}>
                                {visual.icon}
                              </div>
                              <div className="flex-1 min-w-0">
                                <div className="font-bold text-[#2D231E] text-xs truncate">{p.product}</div>
                                <div className="text-[10px] text-[#7A6A60] truncate">{visual.badgeLabel}</div>
                              </div>
                              <div className="text-xs font-mono font-bold text-[#B86B43] text-right">
                                ${p.totalNetRevenue.toLocaleString('en-US', { minimumFractionDigits: 2 })}
                              </div>
                            </div>
                            <div className="flex justify-between text-[11px] text-[#7A6A60] font-mono pt-1 border-t border-[#F5EFE7]">
                              <span>{p.totalUnits.toLocaleString('en-US')} units</span>
                              <span>${p.avgNetUnitPrice.toFixed(2)} avg price</span>
                            </div>
                            <div className="flex justify-between text-[10px] text-[#A8988C] font-mono">
                              <span>{p.txCount} sales days</span>
                              <span className="text-[#487A53] font-medium">{p.profitMargin}% margin</span>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      ) : (
        /* Product-Level Aggregated View Table with Cozy Café Icons */
        <div className="bg-white border border-[#EAE3D8] rounded-2xl shadow-sm shadow-[#75523F]/5 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-[#2D231E]">
              <thead className="bg-[#FAF7F2] text-[#5C4A3E] text-[11px] uppercase tracking-wider font-semibold border-b border-[#EAE3D8]">
                <tr>
                  <th className="py-3 px-4 w-10"></th>
                  <th
                    onClick={() => toggleSort('product')}
                    className="py-3 px-4 cursor-pointer hover:text-[#2D231E] transition-colors"
                  >
                    <div className="flex items-center gap-1.5">
                      <span>Product & Category</span>
                      {renderSortIcon('product')}
                    </div>
                  </th>
                  <th
                    onClick={() => toggleSort('units')}
                    className="py-3 px-4 cursor-pointer hover:text-[#2D231E] transition-colors text-right"
                  >
                    <div className="flex items-center justify-end gap-1.5">
                      <span>Total Units</span>
                      {renderSortIcon('units')}
                    </div>
                  </th>
                  <th
                    onClick={() => toggleSort('avgPrice')}
                    className="py-3 px-4 cursor-pointer hover:text-[#2D231E] transition-colors text-right"
                  >
                    <div className="flex items-center justify-end gap-1.5">
                      <span>Catalog / Realized</span>
                      {renderSortIcon('avgPrice')}
                    </div>
                  </th>
                  <th className="py-3 px-4 text-right">Gross Sales</th>
                  <th className="py-3 px-4 text-right">Discounts</th>
                  <th
                    onClick={() => toggleSort('netRevenue')}
                    className="py-3 px-4 cursor-pointer hover:text-[#2D231E] transition-colors text-right"
                  >
                    <div className="flex items-center justify-end gap-1.5">
                      <span className="text-[#B86B43]">Total Net Revenue</span>
                      {renderSortIcon('netRevenue')}
                    </div>
                  </th>
                  <th className="py-3 px-4 w-32">Revenue Share</th>
                  <th
                    onClick={() => toggleSort('profit')}
                    className="py-3 px-4 cursor-pointer hover:text-[#2D231E] transition-colors text-right"
                  >
                    <div className="flex items-center justify-end gap-1.5">
                      <span>Gross Profit</span>
                      {renderSortIcon('profit')}
                    </div>
                  </th>
                  <th className="py-3 px-4 text-center">Café Distribution</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#F2ECE3] font-sans">
                {aggregatedProducts.map((p, idx) => {
                  const isExpanded = expandedProduct === p.product;
                  const revShare = selectionTotals.netRevenue > 0
                    ? (p.totalNetRevenue / selectionTotals.netRevenue) * 100
                    : 0;
                  const visual = getProductVisual(p.product, p.category);

                  return (
                    <React.Fragment key={p.product}>
                      <tr
                        onClick={() => setExpandedProduct(isExpanded ? null : p.product)}
                        className={`transition-colors cursor-pointer group ${
                          isExpanded ? 'bg-[#FAF7F2]' : 'hover:bg-[#FAF7F2]/80'
                        }`}
                      >
                        {/* Expand Chevron */}
                        <td className="py-3.5 px-4 text-[#A8988C] group-hover:text-[#B86B43] transition-colors">
                          {isExpanded ? (
                            <ChevronDown className="w-4 h-4 text-[#B86B43]" />
                          ) : (
                            <ChevronRight className="w-4 h-4" />
                          )}
                        </td>

                        {/* Product & Icon Visual Accent */}
                        <td className="py-3.5 px-4">
                          <div className="flex items-center space-x-3">
                            {/* Minimalist Illustrated Icon container matching example.jpg style */}
                            <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${visual.bgClass} ${visual.textClass} border ${visual.borderClass} shadow-2xs group-hover:scale-105 transition-transform`}>
                              {visual.icon}
                            </div>
                            <div>
                              <div className="font-bold text-[#2D231E] group-hover:text-[#B86B43] transition-colors text-sm">
                                {p.product}
                              </div>
                              <div className="flex items-center gap-1.5 mt-0.5">
                                <span className="px-2 py-0.5 rounded-full text-[10px] font-medium bg-[#F7F2EB] border border-[#EAE3D8] text-[#5C4A3E]">
                                  {p.category}
                                </span>
                                <span className="text-[10px] text-[#A8988C] font-mono">
                                  {visual.badgeLabel}
                                </span>
                              </div>
                            </div>
                          </div>
                        </td>

                        {/* Total Units */}
                        <td className="py-3.5 px-4 text-right font-mono font-bold text-[#2D231E] text-sm">
                          {p.totalUnits.toLocaleString('en-US')}
                          <span className="block text-[10px] font-normal text-[#7A6A60]">units</span>
                        </td>

                        {/* Unit Price */}
                        <td className="py-3.5 px-4 text-right font-mono text-[#2D231E]">
                          <div>${p.avgNetUnitPrice.toFixed(2)}</div>
                          <span className="text-[10px] text-[#A8988C] line-through">
                            ${p.catalogUnitPrice.toFixed(2)} list
                          </span>
                        </td>

                        {/* Gross Sales */}
                        <td className="py-3.5 px-4 text-right font-mono text-[#5C4A3E]">
                          ${p.totalGrossAmount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </td>

                        {/* Discounts */}
                        <td className="py-3.5 px-4 text-right font-mono text-[#C2584A]">
                          {p.totalDiscount > 0 ? (
                            <span>-${p.totalDiscount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                          ) : (
                            <span className="text-[#A8988C]">$0.00</span>
                          )}
                        </td>

                        {/* Net Revenue */}
                        <td className="py-3.5 px-4 text-right font-mono font-bold text-[#B86B43] text-sm bg-[#FDF9F5]/70 group-hover:bg-[#FDF3E7]/50 transition-colors">
                          ${p.totalNetRevenue.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        </td>

                        {/* Revenue Share Bar (Warm Terracotta Gradient) */}
                        <td className="py-3.5 px-4">
                          <div className="space-y-1">
                            <div className="flex justify-between text-[10px] font-mono">
                              <span className="text-[#7A6A60]">Share</span>
                              <span className="text-[#B86B43] font-bold">{revShare.toFixed(1)}%</span>
                            </div>
                            <div className="h-2 w-full bg-[#EFE9DF] rounded-full overflow-hidden">
                              <div
                                style={{ width: `${Math.min(100, revShare)}%` }}
                                className="h-full bg-gradient-to-r from-[#B86B43] to-[#DDA77B] rounded-full"
                              />
                            </div>
                          </div>
                        </td>

                        {/* Profit & Margin */}
                        <td className="py-3.5 px-4 text-right font-mono">
                          <div className="text-[#487A53] font-bold">
                            ${p.totalProfit.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                          </div>
                          <span className="text-[10px] text-[#7A6A60]">
                            {p.profitMargin}% margin
                          </span>
                        </td>

                        {/* Location Breakdown Badges */}
                        <td className="py-3.5 px-4">
                          <div className="flex flex-wrap items-center justify-center gap-1 max-w-[200px] mx-auto text-[10px] font-mono">
                            {Object.entries(p.cafeBreakdown).map(([cafeName, stat]) => (
                              <span
                                key={cafeName}
                                title={`${cafeName}: ${stat.units} units ($${stat.revenue.toFixed(2)})`}
                                className="px-1.5 py-0.5 rounded bg-[#F7F2EB] border border-[#EAE3D8] text-[#5C4A3E]"
                              >
                                {cafeName.slice(0, 3)}: <strong className="text-[#2D231E]">{stat.units}</strong>
                              </span>
                            ))}
                          </div>
                        </td>
                      </tr>

                      {/* Drill-down expanded view for clicked product */}
                      {isExpanded && (
                        <tr>
                          <td colSpan={10} className="bg-[#FAF7F2] p-5 border-y border-[#EAE3D8]">
                            <div className="space-y-3.5">
                              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#EAE3D8]">
                                <div className="flex items-center space-x-2.5">
                                  <div className="w-8 h-8 rounded-xl bg-[#F5EDE4] border border-[#E8DACB] flex items-center justify-center text-[#8C5338]">
                                    <Calendar className="w-4 h-4" />
                                  </div>
                                  <div>
                                    <h4 className="text-sm font-bold text-[#2D231E] flex items-center gap-2">
                                      <span>Daily POS Breakdown: {p.product}</span>
                                      <span className="text-xs font-mono font-normal text-[#B86B43]">
                                        ({p.dailyBreakdown.length} sales logs in June 2026)
                                      </span>
                                    </h4>
                                    <p className="text-[11px] text-[#7A6A60]">
                                      Audited atomic transactions for {p.product} across cafés. Cashier column omitted per Rule 3.
                                    </p>
                                  </div>
                                </div>

                                <div className="flex items-center gap-2 text-xs font-mono">
                                  <span className="px-2.5 py-1 rounded-lg bg-white border border-[#EAE3D8] text-[#5C4A3E] shadow-2xs">
                                    Avg: {(p.totalUnits / p.dailyBreakdown.length).toFixed(1)} units/day
                                  </span>
                                  <span className="px-2.5 py-1 rounded-lg bg-[#F5EDE4] border border-[#E8DACB] text-[#8C5338] font-bold shadow-2xs">
                                    Total: ${p.totalNetRevenue.toFixed(2)}
                                  </span>
                                </div>
                              </div>

                              {/* Daily Transactions Sub-table */}
                              <div className="max-h-72 overflow-y-auto rounded-xl border border-[#EAE3D8] bg-white shadow-2xs">
                                <table className="w-full text-left text-[11px] text-[#2D231E]">
                                  <thead className="bg-[#FAF7F2] text-[#5C4A3E] uppercase tracking-wider font-semibold sticky top-0 border-b border-[#EAE3D8]">
                                    <tr>
                                      <th className="py-2.5 px-3">Date</th>
                                      <th className="py-2.5 px-3">Café</th>
                                      <th className="py-2.5 px-3">Channel</th>
                                      <th className="py-2.5 px-3 text-right">Units</th>
                                      <th className="py-2.5 px-3 text-right">Unit Price</th>
                                      <th className="py-2.5 px-3 text-right">Discount %</th>
                                      <th className="py-2.5 px-3 text-right">Net Revenue</th>
                                      <th className="py-2.5 px-3 text-right">Cost</th>
                                      <th className="py-2.5 px-3 text-right">Profit</th>
                                    </tr>
                                  </thead>
                                  <tbody className="divide-y divide-[#F2ECE3] font-mono">
                                    {p.dailyBreakdown.map((r, dIdx) => (
                                      <tr key={r.id || dIdx} className="hover:bg-[#FAF7F2] transition-colors">
                                        <td className="py-2 px-3 font-medium text-[#2D231E]">{r.date}</td>
                                        <td className="py-2 px-3 font-sans font-medium text-[#5C4A3E]">{r.cafe}</td>
                                        <td className="py-2 px-3 font-sans">
                                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-medium ${
                                            r.channel === 'Dine-in'
                                              ? 'bg-[#FDF3E7] text-[#B26B2E] border border-[#F4DEC4]'
                                              : 'bg-[#EEF4EE] text-[#487A53] border border-[#D4E4D4]'
                                          }`}>
                                            {r.channel}
                                          </span>
                                        </td>
                                        <td className="py-2 px-3 text-right font-bold text-[#2D231E]">{r.units}</td>
                                        <td className="py-2 px-3 text-right text-[#7A6A60]">${r.unitPrice.toFixed(2)}</td>
                                        <td className="py-2 px-3 text-right">
                                          {r.discountPct > 0 ? (
                                            <span className="text-[#C2584A] font-medium">{r.discountPct}%</span>
                                          ) : (
                                            <span className="text-[#A8988C]">0%</span>
                                          )}
                                        </td>
                                        <td className="py-2 px-3 text-right font-bold text-[#B86B43]">
                                          ${r.netRevenue.toFixed(2)}
                                        </td>
                                        <td className="py-2 px-3 text-right text-[#7A6A60]">${r.cost.toFixed(2)}</td>
                                        <td className="py-2 px-3 text-right text-[#487A53]">${r.profit.toFixed(2)}</td>
                                      </tr>
                                    ))}
                                  </tbody>
                                </table>
                              </div>
                            </div>
                          </td>
                        </tr>
                      )}
                    </React.Fragment>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Footer Summary Bar */}
          <div className="p-4 bg-[#FAF7F2] border-t border-[#EAE3D8] flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-[#5C4A3E]">
            <div>
              Aggregated <strong className="text-[#2D231E]">{aggregatedProducts.length}</strong> products matching filter criteria
              {selectedCafe !== 'all' && (
                <span> for <strong className="text-[#B86B43]">{selectedCafe}</strong></span>
              )}
              {selectedCategory !== 'all' && (
                <span> in <strong className="text-[#487A53]">{selectedCategory}</strong></span>
              )}
            </div>

            <div className="flex items-center gap-4 font-mono">
              <div>
                Total Units: <strong className="text-[#2D231E]">{selectionTotals.units.toLocaleString('en-US')}</strong>
              </div>
              <div className="h-4 w-px bg-[#D9CEC1]" />
              <div>
                Total Net Revenue: <strong className="text-[#B86B43]">${selectionTotals.netRevenue.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</strong>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
