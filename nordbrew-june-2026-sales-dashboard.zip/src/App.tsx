/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, useEffect } from 'react';
import { 
  BarChart3, 
  Table, 
  ShieldCheck, 
  CheckCircle2,
  Coffee,
  Sparkles,
  Sun,
  Lock,
  UserCheck,
  Building2,
  Store,
  Layers,
  ArrowRight
} from 'lucide-react';
import { SalesRecord, ExcludedRow, AuditReport, UserProfile } from './types';
import { 
  CANONICAL_RECORDS, 
  CANONICAL_EXCLUDED_ROWS, 
  CANONICAL_AUDIT_REPORT 
} from './utils/realData';
import { DEMO_USERS } from './utils/authConfig';
import { parseNordBrewFile } from './utils/excelParser';
import { Header } from './components/Header';
import { AuditBanner } from './components/AuditBanner';
import { FileUploader } from './components/FileUploader';
import { MetricsSummary } from './components/MetricsSummary';
import { TransactionsTable } from './components/TransactionsTable';
import { SalesCharts } from './components/SalesCharts';
import { ProductSummaryView } from './components/ProductSummaryView';
import { ExcludedRowsModal } from './components/ExcludedRowsModal';
import { StepTwoConfirmModal } from './components/StepTwoConfirmModal';
import { AuthModal } from './components/AuthModal';

export default function App() {
  const [records, setRecords] = useState<SalesRecord[]>(CANONICAL_RECORDS);
  const [excludedRows, setExcludedRows] = useState<ExcludedRow[]>(CANONICAL_EXCLUDED_ROWS);
  const [auditReport, setAuditReport] = useState<AuditReport>(CANONICAL_AUDIT_REPORT);

  // Authentication & RBAC Session State
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(() => {
    try {
      const saved = sessionStorage.getItem('nordbrew_auth_user');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  const isAuthenticated = currentUser !== null;
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(!isAuthenticated);
  const [isSwitchingUser, setIsSwitchingUser] = useState(false);

  // Active view tab
  const [activeTab, setActiveTab] = useState<'products' | 'analytics' | 'transactions' | 'rules'>('products');
  const [isExcludedModalOpen, setIsExcludedModalOpen] = useState(false);
  const [isStepTwoModalOpen, setIsStepTwoModalOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [notification, setNotification] = useState<string | null>(null);

  // Handle successful login & MFA verification
  const handleLoginSuccess = (user: UserProfile) => {
    setCurrentUser(user);
    try {
      sessionStorage.setItem('nordbrew_auth_user', JSON.stringify(user));
    } catch {
      // storage unavailable
    }
    setIsAuthModalOpen(false);
    setIsSwitchingUser(false);
    setNotification(`Authenticated via MFA as ${user.name} (${user.title}). Scope: ${user.role === 'admin' ? 'Global Baseline ($115,547.88)' : `${user.assignedCafe} Store View`}`);
    setTimeout(() => setNotification(null), 5000);
  };

  // Switch persona modal trigger
  const handleOpenSwitchUser = () => {
    setIsSwitchingUser(true);
    setIsAuthModalOpen(true);
  };

  // Sign out
  const handleLogout = () => {
    setCurrentUser(null);
    try {
      sessionStorage.removeItem('nordbrew_auth_user');
    } catch {
      // ignore
    }
    setIsSwitchingUser(false);
    setIsAuthModalOpen(true);
  };

  // Quick switch between personas (convenience helper for reviewers)
  const handleQuickSwitchRole = (user: UserProfile) => {
    setCurrentUser(user);
    try {
      sessionStorage.setItem('nordbrew_auth_user', JSON.stringify(user));
    } catch {
      // ignore
    }
    setNotification(`Active role switched to: ${user.name} (${user.title}). Scope updated.`);
    setTimeout(() => setNotification(null), 4000);
  };

  // Role-Based Data Scoping (RBAC)
  const scopedRecords = useMemo(() => {
    if (!currentUser) return [];
    if (currentUser.role === 'admin' || currentUser.assignedCafe === 'all') {
      return records;
    }
    return records.filter((r) => r.cafe === currentUser.assignedCafe);
  }, [records, currentUser]);

  const scopedNetRevenue = useMemo(() => {
    if (!currentUser) return 0;
    if (currentUser.role === 'admin' || currentUser.assignedCafe === 'all') {
      return auditReport.netRevenueTotal;
    }
    const sum = scopedRecords.reduce((acc, r) => acc + r.netRevenue, 0);
    return Math.round(sum * 100) / 100;
  }, [scopedRecords, currentUser, auditReport]);

  // Handle uploaded Excel or CSV file
  const handleFileParsed = (fileBuffer: ArrayBuffer | string, fileName: string) => {
    setIsLoading(true);
    try {
      const result = parseNordBrewFile(fileBuffer, fileName);
      setRecords(result.records);
      setExcludedRows(result.excludedRows);
      setAuditReport(result.auditReport);
      setNotification(`Processed "${fileName}" — Audited ${result.records.length} transactions.`);
      setTimeout(() => setNotification(null), 4000);
    } catch (err: any) {
      alert(`Error parsing file: ${err?.message || 'Invalid format'}`);
    } finally {
      setIsLoading(false);
    }
  };

  // Reset to canonical benchmark dataset
  const handleResetToCanonical = () => {
    setIsLoading(true);
    setTimeout(() => {
      setRecords(CANONICAL_RECORDS);
      setExcludedRows(CANONICAL_EXCLUDED_ROWS);
      setAuditReport(CANONICAL_AUDIT_REPORT);
      setIsLoading(false);
      setNotification('Reset to canonical June 2026 audited dataset.');
      setTimeout(() => setNotification(null), 3000);
    }, 200);
  };

  return (
    <div className="min-h-screen bg-[#FAF7F2] text-[#2D231E] flex flex-col font-sans selection:bg-[#E8DACB] selection:text-[#5C3828] relative">
      {/* Top Header */}
      <Header
        validCount={currentUser?.role === 'admin' ? records.length : scopedRecords.length}
        netRevenue={currentUser?.role === 'admin' ? auditReport.netRevenueTotal : scopedNetRevenue}
        isReconciled={auditReport.isReconciled}
        onStepTwoReady={() => setIsStepTwoModalOpen(true)}
        currentUser={currentUser}
        onSwitchUser={handleOpenSwitchUser}
        onLogout={handleLogout}
      />

      {/* Main Container - strictly blurred/obscured if not authenticated */}
      <main className={`flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 transition-all duration-300 ${
        !isAuthenticated ? 'filter blur-md pointer-events-none select-none opacity-40' : ''
      }`}>
        {/* Toast Notification */}
        {notification && (
          <div className="mb-4 p-3.5 rounded-2xl bg-[#EEF4EE] border border-[#D4E4D4] text-[#2D231E] text-xs flex items-center justify-between shadow-xs animate-in slide-in-from-top duration-300">
            <div className="flex items-center space-x-2.5">
              <CheckCircle2 className="w-4 h-4 text-[#487A53] shrink-0" />
              <span className="font-semibold">{notification}</span>
            </div>
            <button
              onClick={() => setNotification(null)}
              className="text-[#487A53] hover:text-[#2D231E] text-xs px-2 py-0.5 rounded-lg cursor-pointer font-bold"
            >
              Dismiss
            </button>
          </div>
        )}

        {/* Enterprise RBAC Persona & Scope Status Bar */}
        {currentUser && (
          <div className="mb-6 p-4 rounded-2xl bg-white border border-[#EAE3D8] shadow-sm shadow-[#75523F]/5 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
            <div className="flex items-center space-x-3.5">
              <div className={`w-10 h-10 rounded-2xl bg-gradient-to-tr ${currentUser.avatarColor || 'from-[#B86B43] to-[#DDA77B]'} text-white flex items-center justify-center font-bold text-sm shadow-xs`}>
                {currentUser.name.slice(0, 1)}
              </div>
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-xs font-bold text-[#2D231E]">{currentUser.name}</span>
                  <span className={`text-[10px] font-bold px-2 py-0.2 rounded-full uppercase tracking-wider ${
                    currentUser.role === 'admin'
                      ? 'bg-[#FDF3E7] text-[#B26B2E] border border-[#F4DEC4]'
                      : 'bg-[#EEF4EE] text-[#487A53] border border-[#D4E4D4]'
                  }`}>
                    {currentUser.role === 'admin' ? 'Admin / Finance Role' : `Store Manager • ${currentUser.assignedCafe}`}
                  </span>
                  <span className="text-[10px] text-[#3F754E] bg-[#EBF4ED] border border-[#CDE3D2] px-2 py-0.2 rounded-full font-medium">
                    MFA Verified Session
                  </span>
                </div>
                <p className="text-xs text-[#7A6A60] mt-0.5">
                  {currentUser.role === 'admin' ? (
                    <span>Full Enterprise Access across all 4 locations (Riga, Tallinn, Vilnius, Helsinki). Reconciles to <strong>$115,547.88</strong> across 1,181 rows.</span>
                  ) : (
                    <span>Restricted Regional Access. Scoped strictly to <strong>{currentUser.assignedCafe}</strong> ({scopedRecords.length} rows, <strong>${scopedNetRevenue.toLocaleString('en-US', { minimumFractionDigits: 2 })}</strong>).</span>
                  )}
                </p>
              </div>
            </div>

            {/* Quick Persona Switcher for easy testing & review */}
            <div className="flex items-center gap-1.5 flex-wrap self-start lg:self-auto text-[11px]">
              <span className="text-[#A8988C] font-medium whitespace-nowrap">Switch Role:</span>
              <button
                onClick={() => handleQuickSwitchRole(DEMO_USERS[0])}
                className={`px-2.5 py-1 rounded-xl transition-all cursor-pointer font-medium ${
                  currentUser.id === DEMO_USERS[0].id
                    ? 'bg-[#B86B43] text-white font-bold shadow-xs'
                    : 'bg-[#F7F2EB] text-[#5C4A3E] hover:text-[#2D231E] border border-[#EAE3D8]'
                }`}
                title="Global Admin: All 4 locations ($115,547.88)"
              >
                Admin (All 4 Hubs)
              </button>
              <button
                onClick={() => handleQuickSwitchRole(DEMO_USERS[1])}
                className={`px-2.5 py-1 rounded-xl transition-all cursor-pointer font-medium ${
                  currentUser.id === DEMO_USERS[1].id
                    ? 'bg-[#B86B43] text-white font-bold shadow-xs'
                    : 'bg-[#F7F2EB] text-[#5C4A3E] hover:text-[#2D231E] border border-[#EAE3D8]'
                }`}
                title="Tallinn Store Manager ($42,973.77)"
              >
                Tallinn Mgr
              </button>
              <button
                onClick={() => handleQuickSwitchRole(DEMO_USERS[2])}
                className={`px-2.5 py-1 rounded-xl transition-all cursor-pointer font-medium ${
                  currentUser.id === DEMO_USERS[2].id
                    ? 'bg-[#B86B43] text-white font-bold shadow-xs'
                    : 'bg-[#F7F2EB] text-[#5C4A3E] hover:text-[#2D231E] border border-[#EAE3D8]'
                }`}
                title="Riga Store Manager ($30,848.03)"
              >
                Riga Mgr
              </button>
              <button
                onClick={() => handleQuickSwitchRole(DEMO_USERS[3])}
                className={`px-2.5 py-1 rounded-xl transition-all cursor-pointer font-medium ${
                  currentUser.id === DEMO_USERS[3].id
                    ? 'bg-[#B86B43] text-white font-bold shadow-xs'
                    : 'bg-[#F7F2EB] text-[#5C4A3E] hover:text-[#2D231E] border border-[#EAE3D8]'
                }`}
                title="Vilnius Store Manager ($25,081.87)"
              >
                Vilnius Mgr
              </button>
              <button
                onClick={() => handleQuickSwitchRole(DEMO_USERS[4])}
                className={`px-2.5 py-1 rounded-xl transition-all cursor-pointer font-medium ${
                  currentUser.id === DEMO_USERS[4].id
                    ? 'bg-[#B86B43] text-white font-bold shadow-xs'
                    : 'bg-[#F7F2EB] text-[#5C4A3E] hover:text-[#2D231E] border border-[#EAE3D8]'
                }`}
                title="Helsinki Store Manager ($16,644.21)"
              >
                Helsinki Mgr
              </button>
            </div>
          </div>
        )}

        {/* Step 1 & 2 Verification and 3x Trap Breakdown */}
        <AuditBanner
          auditReport={auditReport}
          onViewExcludedRows={() => setIsExcludedModalOpen(true)}
          currentUser={currentUser}
          scopedCount={scopedRecords.length}
          scopedRevenue={scopedNetRevenue}
        />

        {/* Source File & Uploader Controls (Admin only for full uploads) */}
        {currentUser?.role === 'admin' ? (
          <FileUploader
            auditReport={auditReport}
            cleanedRecords={records}
            onFileParsed={handleFileParsed}
            onResetToCanonical={handleResetToCanonical}
            isLoading={isLoading}
          />
        ) : (
          <div className="mb-6 p-4 rounded-2xl bg-[#FAF7F2] border border-[#EAE3D8] flex items-center justify-between text-xs text-[#7A6A60]">
            <div className="flex items-center gap-2">
              <Lock className="w-4 h-4 text-[#B86B43]" />
              <span>
                Source spreadsheet ingestion controls are restricted to <strong>Admin / Finance</strong>. Operating on verified canonical POS data.
              </span>
            </div>
            <button
              onClick={() => handleQuickSwitchRole(DEMO_USERS[0])}
              className="text-[#B86B43] hover:text-[#A55B35] font-semibold underline cursor-pointer"
            >
              Switch to Admin
            </button>
          </div>
        )}

        {/* Executive KPI Stats - Scoped to User Role */}
        <MetricsSummary records={scopedRecords} netRevenue={scopedNetRevenue} />

        {/* View Selection Tabs with Warm Café Aesthetic */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3.5 mb-6 border-b border-[#EAE3D8] pb-3.5">
          <div className="flex flex-wrap items-center gap-2">
            {/* 1. Product & Category Summary Tab (Pivot / Aggregation) */}
            <button
              onClick={() => setActiveTab('products')}
              className={`px-4 py-2.5 rounded-2xl text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer ${
                activeTab === 'products'
                  ? 'bg-[#B86B43] text-white shadow-xs font-bold'
                  : 'text-[#7A6A60] hover:text-[#2D231E] hover:bg-[#F2ECE3] border border-transparent'
              }`}
            >
              <Coffee className="w-4 h-4" />
              <span>Product & Category Summary</span>
              <span className={`text-[10px] px-2 py-0.2 rounded-full font-mono font-bold ${
                activeTab === 'products' ? 'bg-white/20 text-white' : 'bg-[#FDF3E7] text-[#B26B2E] border border-[#F4DEC4]'
              }`}>
                Pivot
              </span>
            </button>

            {/* 2. Full Transactions Tab */}
            <button
              onClick={() => setActiveTab('transactions')}
              className={`px-4 py-2.5 rounded-2xl text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer ${
                activeTab === 'transactions'
                  ? 'bg-[#B86B43] text-white shadow-xs font-bold'
                  : 'text-[#7A6A60] hover:text-[#2D231E] hover:bg-[#F2ECE3] border border-transparent'
              }`}
            >
              <Table className="w-4 h-4" />
              <span>Transactions ({scopedRecords.length})</span>
            </button>

            {/* 3. Analytics & Visuals Tab */}
            <button
              onClick={() => setActiveTab('analytics')}
              className={`px-4 py-2.5 rounded-2xl text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer ${
                activeTab === 'analytics'
                  ? 'bg-[#B86B43] text-white shadow-xs font-bold'
                  : 'text-[#7A6A60] hover:text-[#2D231E] hover:bg-[#F2ECE3] border border-transparent'
              }`}
            >
              <BarChart3 className="w-4 h-4" />
              <span>Visual Analytics</span>
            </button>

            {/* 4. Ingestion Rules Tab */}
            <button
              onClick={() => setActiveTab('rules')}
              className={`px-4 py-2.5 rounded-2xl text-xs font-semibold flex items-center gap-2 transition-all cursor-pointer ${
                activeTab === 'rules'
                  ? 'bg-[#B86B43] text-white shadow-xs font-bold'
                  : 'text-[#7A6A60] hover:text-[#2D231E] hover:bg-[#F2ECE3] border border-transparent'
              }`}
            >
              <ShieldCheck className="w-4 h-4" />
              <span>Audit Rules & Trap Specs</span>
            </button>
          </div>

          {/* Quick View Toggle */}
          <div className="flex items-center gap-1 bg-[#F7F2EB] border border-[#EAE3D8] p-1 rounded-xl text-[11px] self-start sm:self-auto font-medium shadow-2xs">
            <button
              onClick={() => setActiveTab('products')}
              className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                activeTab === 'products'
                  ? 'bg-white text-[#2D231E] shadow-2xs font-bold'
                  : 'text-[#7A6A60] hover:text-[#2D231E]'
              }`}
            >
              Summary View
            </button>
            <button
              onClick={() => setActiveTab('transactions')}
              className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                activeTab === 'transactions'
                  ? 'bg-white text-[#2D231E] shadow-2xs font-bold'
                  : 'text-[#7A6A60] hover:text-[#2D231E]'
              }`}
            >
              Daily Rows
            </button>
          </div>
        </div>

        {/* Tab 1: Product & Category Summary View (Pivot / Aggregation) */}
        {activeTab === 'products' && (
          <div className="space-y-6">
            <ProductSummaryView records={scopedRecords} currentUser={currentUser} />
          </div>
        )}

        {/* Tab 2: Transaction-Level Daily View */}
        {activeTab === 'transactions' && (
          <div className="space-y-6">
            <TransactionsTable records={scopedRecords} currentUser={currentUser} />
          </div>
        )}

        {/* Tab 3: Visual Analytics */}
        {activeTab === 'analytics' && (
          <div className="space-y-6">
            <SalesCharts records={scopedRecords} />
            <TransactionsTable records={scopedRecords} currentUser={currentUser} />
          </div>
        )}

        {/* Tab 4: Ingestion Audit Rules & Specifications */}
        {activeTab === 'rules' && (
          <div className="space-y-6">
            <div className="bg-white border border-[#EAE3D8] rounded-2xl p-6 sm:p-7 shadow-sm shadow-[#75523F]/5">
              <h3 className="text-base font-bold text-[#2D231E] mb-2 flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-[#F5EDE4] border border-[#E8DACB] flex items-center justify-center text-[#8C5338]">
                  <ShieldCheck className="w-4 h-4" />
                </div>
                <span>Step 1 & 2 Ingestion Rules & Enterprise Security Specifications</span>
              </h3>
              <p className="text-xs text-[#7A6A60] mb-6">
                Technical reconciliation documentation for NordBrew June 2026 Sales dataset (<code className="text-[#2D231E] font-bold">S3mini_NordBrew_June2026_Sales_RAW.xlsx</code>, sheet <code className="text-[#2D231E] font-bold">Sales</code>).
              </p>

              <div className="space-y-4 text-xs text-[#5C4A3E]">
                <div className="p-4 rounded-xl bg-[#FAF7F2] border border-[#EAE3D8]">
                  <h4 className="font-bold text-[#2D231E] mb-1">1. Skip Title Rows 1–3, Header on Row 4</h4>
                  <p className="text-[#7A6A60] leading-relaxed">
                    Rows 1–3 contain report title and period metadata (<code className="text-[#2D231E] font-mono">NordBrew Coffee & Bakery — Daily Sales Export</code>).
                    The parser offsets 3 rows and designates row 4 as the column headers: <code className="text-[#2D231E] font-mono">date, cafe, product, category, channel, units, unit_price, discount_pct, unit_cost, net_revenue, cashier</code>.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-[#FAF7F2] border border-[#EAE3D8]">
                  <h4 className="font-bold text-[#2D231E] mb-1">2. Exclude the 4 SUBTOTAL Rows and the GRAND TOTAL Row</h4>
                  <p className="text-[#7A6A60] leading-relaxed">
                    By checking the <strong className="text-[#2D231E]">Product</strong> column, rows labeled with <code className="text-[#B86B43] font-mono font-bold">SUBTOTAL Tallinn</code> ($42,973.77), <code className="text-[#B86B43] font-mono font-bold">SUBTOTAL Riga</code> ($30,848.03), <code className="text-[#B86B43] font-mono font-bold">SUBTOTAL Vilnius</code> ($25,081.87), <code className="text-[#B86B43] font-mono font-bold">SUBTOTAL Helsinki</code> ($16,644.21), and <code className="text-[#C2584A] font-mono font-bold">GRAND TOTAL</code> ($115,547.88) are intercepted and excluded from the atomic transaction count.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-[#FAF7F2] border border-[#EAE3D8]">
                  <h4 className="font-bold text-[#2D231E] mb-1">3. Drop the Cashier Column Entirely</h4>
                  <p className="text-[#7A6A60] leading-relaxed">
                    The raw <code className="text-[#2D231E] font-mono font-bold">cashier</code> column (column index 10) is omitted from the data model and does not appear in transaction views or downstream aggregations.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-[#FAF7F2] border border-[#EAE3D8]">
                  <h4 className="font-bold text-[#2D231E] mb-1">4. The 3× Total Trap Defense</h4>
                  <p className="text-[#7A6A60] leading-relaxed">
                    Summing the uncleaned net revenue column blindly yields <strong className="text-[#C2584A] font-mono font-bold">$346,643.64</strong> because the 1,181 transactions ($115,547.88), the 4 subtotals ($115,547.88), and the grand total ($115,547.88) are all present in the same column.
                    Our pipeline intercepts all 5 non-transaction rows, reconciling exactly to <strong className="text-[#487A53] font-mono font-bold">$115,547.88</strong> across <strong className="text-[#487A53] font-mono font-bold">1,181</strong> valid rows.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-[#FAF7F2] border border-[#EAE3D8]">
                  <h4 className="font-bold text-[#2D231E] mb-1">5. Enterprise RBAC & MFA Security Layer</h4>
                  <p className="text-[#7A6A60] leading-relaxed">
                    Unauthenticated users are strictly barred from accessing any revenue figures. Admin / Finance accounts view the full 4-city baseline ($115,547.88), while Store Managers are cryptographically scoped to their assigned store location (Tallinn $42,973.77, Riga $30,848.03, Vilnius $25,081.87, Helsinki $16,644.21).
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-[#EAE3D8] bg-white py-5 text-center text-xs text-[#7A6A60] font-mono">
        NordBrew Coffee Roasters © June 2026 Sales Intelligence Pipeline • Reconciled $115,547.88 across 1,181 rows • RBAC & MFA Active
      </footer>

      {/* Modals */}
      <ExcludedRowsModal
        isOpen={isExcludedModalOpen}
        onClose={() => setIsExcludedModalOpen(false)}
        excludedRows={excludedRows}
      />

      <StepTwoConfirmModal
        isOpen={isStepTwoModalOpen}
        onClose={() => setIsStepTwoModalOpen(false)}
        validCount={records.length}
        netRevenue={auditReport.netRevenueTotal}
      />

      {/* Secure Authentication & MFA Modal */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onLoginSuccess={handleLoginSuccess}
        currentUser={currentUser}
        onClose={() => setIsAuthModalOpen(false)}
        isSwitchingUser={isSwitchingUser}
      />
    </div>
  );
}
