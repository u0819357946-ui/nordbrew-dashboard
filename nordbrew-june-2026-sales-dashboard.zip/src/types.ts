export interface SalesRecord {
  id: string;
  transactionId: string;
  date: string;
  cafe: string;
  product: string;
  category: string;
  channel: string;
  units: number;
  unitPrice: number;
  discountPct: number;
  unitCost: number;
  grossAmount: number;
  discount: number;
  netRevenue: number;
  cost: number;
  profit: number;
}

export interface ExcludedRow {
  rowNumber: number;
  product: string;
  type: 'subtotal' | 'grand_total';
  amount: number;
  rawText: string;
}

export interface AuditReport {
  fileName: string;
  sheetName: string;
  totalRawRowsProcessed: number;
  titleRowsSkipped: number;
  headerRowIndex: number;
  droppedCashierColumn: boolean;
  validTransactionCount: number;
  subtotalRowsCount: number;
  grandTotalRowsCount: number;
  excludedRows: ExcludedRow[];
  netRevenueTotal: number;
  grossRevenueTotal: number;
  discountTotal: number;
  rawUnfilteredSum: number;
  trapWarningDetected: boolean;
  trapDifference: number;
  isReconciled: boolean;
  statusMessage: string;
}

export type UserRole = 'admin' | 'manager';

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  title: string;
  assignedCafe?: string; // 'all' for admin, or 'Riga' | 'Tallinn' | 'Vilnius' | 'Helsinki'
  phoneHint?: string;
  avatarColor?: string;
}

export interface AuthState {
  isAuthenticated: boolean;
  user: UserProfile | null;
}

