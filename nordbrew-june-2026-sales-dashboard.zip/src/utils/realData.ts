import rawDataset from '../data/nordbrewRealData.json';
import { SalesRecord, ExcludedRow, AuditReport } from '../types';

export const CANONICAL_RECORDS: SalesRecord[] = rawDataset.records as SalesRecord[];
export const CANONICAL_EXCLUDED_ROWS: ExcludedRow[] = rawDataset.excludedRows as ExcludedRow[];
export const CANONICAL_AUDIT_REPORT: AuditReport = rawDataset.audit as AuditReport;

export const TARGET_NET_REVENUE = 115547.88;
export const TARGET_VALID_ROWS = 1181;
export const TRAP_RAW_TOTAL = 346643.64;

export const SUB_TOTALS_BY_CAFE = [
  { cafe: 'Tallinn', amount: 42973.77 },
  { cafe: 'Riga', amount: 30848.03 },
  { cafe: 'Vilnius', amount: 25081.87 },
  { cafe: 'Helsinki', amount: 16644.21 },
];
