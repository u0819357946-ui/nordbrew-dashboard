import React from 'react';
import { 
  Coffee, 
  UtensilsCrossed, 
  Package, 
  Cookie, 
  Sandwich, 
  Wheat, 
  CupSoda, 
  ShoppingBag,
  Sparkles
} from 'lucide-react';

export interface ProductVisualTheme {
  icon: React.ReactNode;
  bgClass: string;
  textClass: string;
  borderClass: string;
  badgeLabel: string;
}

export function getProductVisual(productName: string, category: string): ProductVisualTheme {
  const name = productName.toLowerCase();

  if (name.includes('cappuccino')) {
    return {
      icon: (
        <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M17 8h1a4 44 0 0 1 0 8h-1" />
          <path d="M3 8h14v7a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4Z" />
          <path d="M6 2v2" />
          <path d="M10 2v2" />
          <path d="M14 2v2" />
        </svg>
      ),
      bgClass: 'bg-[#F5EDE4]',
      textClass: 'text-[#8C5338]',
      borderClass: 'border-[#E8DACB]',
      badgeLabel: 'Foam & Espresso',
    };
  }

  if (name.includes('latte')) {
    return {
      icon: (
        <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M18 8h1a4 4 0 0 1 0 8h-1" />
          <path d="M2 8h16v8a4 4 0 0 1-4 4H6a4 4 0 0 1-4-4Z" />
          <path d="M7 11c1-1 3-1 4 0s3 1 4 0" />
        </svg>
      ),
      bgClass: 'bg-[#F9EFE6]',
      textClass: 'text-[#9E6244]',
      borderClass: 'border-[#ECDCCF]',
      badgeLabel: 'Silky Microfoam',
    };
  }

  if (name.includes('espresso')) {
    return {
      icon: (
        <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M16 10h1a3 3 0 0 1 0 6h-1" />
          <path d="M4 10h12v5a3 3 0 0 1-3 3H7a3 3 0 0 1-3-3Z" />
          <path d="M2 20h16" />
          <path d="M8 5c.5-1 1.5-1 2 0" />
        </svg>
      ),
      bgClass: 'bg-[#EDE4DE]',
      textClass: 'text-[#5C3828]',
      borderClass: 'border-[#DFCFC3]',
      badgeLabel: 'Rich Crema',
    };
  }

  if (name.includes('filter') || name.includes('drip')) {
    return {
      icon: (
        <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M4 19h16" />
          <path d="M7 19v-6a5 5 0 0 1 10 0v6" />
          <path d="M12 4v3" />
        </svg>
      ),
      bgClass: 'bg-[#F7EFE8]',
      textClass: 'text-[#87553D]',
      borderClass: 'border-[#EADCCF]',
      badgeLabel: 'Nordic Batch Brew',
    };
  }

  if (name.includes('cinnamon bun')) {
    return {
      icon: (
        <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <circle cx="12" cy="12" r="9" />
          <path d="M12 7a5 5 0 0 1 5 5c0 3-2 4-5 4s-4-1-4-3 1.5-2 4-2" />
        </svg>
      ),
      bgClass: 'bg-[#FDF3E7]',
      textClass: 'text-[#B26B2E]',
      borderClass: 'border-[#F4DEC4]',
      badgeLabel: 'Cardamom & Sugar',
    };
  }

  if (name.includes('croissant')) {
    return {
      icon: (
        <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="m19 12-4-7-4 7" />
          <path d="M15 5h-4" />
          <path d="M5 16c2-4 6-6 10-6s7 2 7 5a6 6 0 0 1-6 6c-3 0-5-2-7-5" />
        </svg>
      ),
      bgClass: 'bg-[#FEF5E7]',
      textClass: 'text-[#B87A32]',
      borderClass: 'border-[#F5E2C4]',
      badgeLabel: 'French Butter Flaky',
    };
  }

  if (name.includes('rye bread')) {
    return {
      icon: <Wheat className="w-4 h-4 text-[#8C6239]" />,
      bgClass: 'bg-[#F6EFEA]',
      textClass: 'text-[#7D532B]',
      borderClass: 'border-[#E8DCD1]',
      badgeLabel: 'Artisan Sourdough',
    };
  }

  if (name.includes('ham & cheese') || name.includes('sandwich')) {
    return {
      icon: <Sandwich className="w-4 h-4 text-[#8A5E3E]" />,
      bgClass: 'bg-[#F4EFEA]',
      textClass: 'text-[#7A5033]',
      borderClass: 'border-[#E7DBD1]',
      badgeLabel: 'Danish Havarti & Rye',
    };
  }

  if (name.includes('wrap') || name.includes('veggie')) {
    return {
      icon: (
        <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M12 2a8 8 0 0 0-8 8c0 5 8 12 8 12s8-7 8-12a8 8 0 0 0-8-8z" />
          <path d="M9 10a3 3 0 0 0 6 0" />
        </svg>
      ),
      bgClass: 'bg-[#EEF4EE]',
      textClass: 'text-[#487A53]',
      borderClass: 'border-[#D4E4D4]',
      badgeLabel: 'Hummus & Crisp Greens',
    };
  }

  if (name.includes('coffee beans') || name.includes('beans')) {
    return {
      icon: (
        <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <ellipse cx="12" cy="12" rx="7" ry="9" transform="rotate(25 12 12)" />
          <path d="M9 6c3 3 3 9 6 12" />
        </svg>
      ),
      bgClass: 'bg-[#F3EBE3]',
      textClass: 'text-[#68402C]',
      borderClass: 'border-[#E2D2C4]',
      badgeLabel: 'Whole Bean Roast',
    };
  }

  if (name.includes('mug')) {
    return {
      icon: (
        <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M17 8h1a4 4 0 0 1 0 8h-1" />
          <path d="M5 8h12v7a4 4 0 0 1-4 4H9a4 4 0 0 1-4-4Z" />
        </svg>
      ),
      bgClass: 'bg-[#F2ECE8]',
      textClass: 'text-[#825442]',
      borderClass: 'border-[#DFD4CD]',
      badgeLabel: 'Nordic Ceramic 350ml',
    };
  }

  // Fallback by category
  if (category === 'Coffee') {
    return {
      icon: <Coffee className="w-4 h-4" />,
      bgClass: 'bg-[#F5EDE4]',
      textClass: 'text-[#8C5338]',
      borderClass: 'border-[#E8DACB]',
      badgeLabel: 'Coffee',
    };
  }
  if (category === 'Pastry') {
    return {
      icon: <Cookie className="w-4 h-4" />,
      bgClass: 'bg-[#FDF3E7]',
      textClass: 'text-[#B26B2E]',
      borderClass: 'border-[#F4DEC4]',
      badgeLabel: 'Bakery',
    };
  }
  if (category === 'Sandwich') {
    return {
      icon: <UtensilsCrossed className="w-4 h-4" />,
      bgClass: 'bg-[#EEF4EE]',
      textClass: 'text-[#487A53]',
      borderClass: 'border-[#D4E4D4]',
      badgeLabel: 'Fresh Deli',
    };
  }

  return {
    icon: <Package className="w-4 h-4" />,
    bgClass: 'bg-[#F3ECE5]',
    textClass: 'text-[#77503B]',
    borderClass: 'border-[#E2D4C6]',
    badgeLabel: 'Retail Goods',
  };
}
