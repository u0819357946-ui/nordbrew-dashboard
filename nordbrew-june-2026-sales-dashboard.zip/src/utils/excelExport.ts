import * as XLSX from 'xlsx';
import { SalesRecord } from '../types';

export function exportCleanedSalesData(records: SalesRecord[]) {
  // Cashier is excluded by definition
  const cleanData = records.map((r) => ({
    'Date': r.date,
    'Cafe': r.cafe,
    'Product': r.product,
    'Category': r.category,
    'Channel': r.channel,
    'Units': r.units,
    'Unit Price': r.unitPrice,
    'Discount %': r.discountPct,
    'Unit Cost': r.unitCost,
    'Net Revenue': r.netRevenue,
  }));

  const ws = XLSX.utils.json_to_sheet(cleanData);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Clean_Sales');
  XLSX.writeFile(wb, 'NordBrew_June2026_Audited_Clean.xlsx');
}
